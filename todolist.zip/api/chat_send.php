<?php
session_start();
include "../config/db.php";

header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])) {
  echo json_encode(['ok' => false, 'msg' => 'Unauthorized']);
  exit;
}

$from    = (int)$_SESSION['user_id'];
$to      = (int)($_POST['to_id'] ?? 0);
$message = trim($_POST['message'] ?? '');

if(!$to || $message === '') {
  echo json_encode(['ok' => false, 'msg' => 'Data tidak lengkap']);
  exit;
}

$message = mysqli_real_escape_string($conn, $message);
mysqli_query($conn, "INSERT INTO chats (from_id, to_id, message, created_at) VALUES ('$from', '$to', '$message', NOW())");

echo json_encode(['ok' => true]);