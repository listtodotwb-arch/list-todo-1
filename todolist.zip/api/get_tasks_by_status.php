<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin'){
  http_response_code(403);
  echo json_encode(['error'=>'Unauthorized']);
  exit;
}

$status = mysqli_real_escape_string($conn, $_GET['status'] ?? '');
$allowed = ['Open','Pending','Process','Closed'];
if(!in_array($status, $allowed)){
  echo json_encode(['error'=>'Status tidak valid']);
  exit;
}

$result = mysqli_query($conn, "SELECT * FROM tasks WHERE status='$status' ORDER BY created_at DESC");
$tasks = [];
while($row = mysqli_fetch_assoc($result)){
  $tasks[] = $row;
}

header('Content-Type: application/json');
echo json_encode($tasks);