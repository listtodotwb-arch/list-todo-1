<?php
session_start();
include "../config/db.php";

header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])) {
  echo json_encode([]);
  exit;
}

$me      = (int)$_SESSION['user_id'];
$partner = (int)($_GET['with'] ?? 0);

if(!$partner) { echo json_encode([]); exit; }

// Tandai semua pesan dari partner ke gw sebagai read
mysqli_query($conn, "UPDATE chats SET is_read=1 WHERE from_id='$partner' AND to_id='$me'");

$res = mysqli_query($conn, "
  SELECT c.*, u.username
  FROM chats c
  JOIN users u ON u.id = c.from_id
  WHERE (c.from_id='$me' AND c.to_id='$partner')
     OR (c.from_id='$partner' AND c.to_id='$me')
  ORDER BY c.created_at ASC
");

$chats = [];
while($row = mysqli_fetch_assoc($res)) {
  $chats[] = [
    'id'         => $row['id'],
    'from_id'    => $row['from_id'],
    'username'   => $row['username'],
    'message'    => $row['message'],
    'created_at' => $row['created_at'],
    'is_me'      => $row['from_id'] == $me,
  ];
}

echo json_encode($chats);