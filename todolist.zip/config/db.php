<?php

$host = "sql213.infinityfree.com";
$user = "if0_41558469";
$pass = "list12345";
$db   = "if0_41558469_listtodo";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Database gagal terhubung");
}

date_default_timezone_set("Asia/Jakarta");

?>