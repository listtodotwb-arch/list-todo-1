<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
  header("Location: ../auth/login.php");
  exit;
}

$uid = $_SESSION['user_id'];

// Ambil semua admin buat chat
$admins = mysqli_query($conn, "SELECT id, username FROM users WHERE role='admin' ORDER BY username ASC");

// unread count
$unread = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chat — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .chat-layout {
      display: grid;
      grid-template-columns: 260px 1fr;
      gap: 20px;
      height: calc(100vh - 130px);
    }
    .chat-sidebar {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }
    .chat-sidebar-title {
      padding: 16px 18px;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--muted);
      border-bottom: 1px solid var(--border);
    }
    .chat-user-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 13px 18px;
      cursor: pointer;
      border-bottom: 1px solid rgba(34,34,48,0.5);
      transition: background 0.15s;
      text-decoration: none;
      color: var(--text);
    }
    .chat-user-item:hover, .chat-user-item.active { background: var(--nav-active); }
    .chat-user-item .av {
      width: 34px; height: 34px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      display: flex; align-items: center; justify-content: center;
      font-size: 0.75rem; font-weight: 800; color: #fff;
      flex-shrink: 0;
    }
    .chat-user-item .name { font-size: 0.87rem; font-weight: 600; }
    .chat-user-item .role-label { font-size: 0.68rem; color: var(--muted); }
    .chat-main {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .chat-header {
      padding: 15px 20px;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      gap: 12px;
      flex-shrink: 0;
    }
    .chat-header .av {
      width: 34px; height: 34px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      display: flex; align-items: center; justify-content: center;
      font-size: 0.75rem; font-weight: 800; color: #fff;
    }
    .chat-header .info .name { font-size: 0.9rem; font-weight: 700; }
    .chat-header .info .sub  { font-size: 0.7rem; color: var(--muted); }
    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .chat-messages::-webkit-scrollbar { width: 4px; }
    .chat-messages::-webkit-scrollbar-track { background: transparent; }
    .chat-messages::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }
    .bubble-wrap { display: flex; flex-direction: column; }
    .bubble-wrap.me { align-items: flex-end; }
    .bubble-wrap.them { align-items: flex-start; }
    .bubble {
      max-width: 70%;
      padding: 10px 14px;
      border-radius: 14px;
      font-size: 0.87rem;
      line-height: 1.5;
      word-break: break-word;
    }
    .bubble.me {
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      color: #fff;
      border-bottom-right-radius: 4px;
    }
    .bubble.them {
      background: rgba(255,255,255,0.07);
      border: 1px solid var(--border);
      color: var(--text);
      border-bottom-left-radius: 4px;
    }
    .bubble-time {
      font-size: 0.65rem;
      color: var(--muted);
      margin-top: 3px;
      padding: 0 4px;
    }
    .chat-input-area {
      padding: 14px 16px;
      border-top: 1px solid var(--border);
      display: flex;
      gap: 10px;
      flex-shrink: 0;
    }
    .chat-input {
      flex: 1;
      background: rgba(255,255,255,0.06);
      border: 1px solid var(--border);
      border-radius: 10px;
      color: var(--text);
      font-size: 0.88rem;
      padding: 10px 14px;
      outline: none;
      resize: none;
      font-family: 'Segoe UI', sans-serif;
      transition: border-color 0.2s;
      max-height: 100px;
    }
    .chat-input:focus { border-color: var(--accent); }
    .chat-input::placeholder { color: var(--muted); }
    .btn-send {
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      border: none;
      border-radius: 10px;
      color: #fff;
      cursor: pointer;
      padding: 10px 18px;
      font-size: 0.85rem;
      font-weight: 700;
      transition: opacity 0.2s;
      flex-shrink: 0;
    }
    .btn-send:hover { opacity: 0.85; }
    .chat-empty {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--muted);
      font-size: 0.85rem;
    }
    .badge-unread {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: #ef4444;
      color: #fff;
      border-radius: 99px;
      font-size: 0.6rem;
      font-weight: 800;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      margin-left: auto;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">User Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="my_tasks.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9.75L12 3l9 6.75V21H3V9.75z"/></svg>
        Task Saya
      </a>
      <a href="chat.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat
        <?php if($unread > 0): ?>
          <span class="badge-unread"><?= $unread ?></span>
        <?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>
        Logout
      </a>
    </div>
  </div>

  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">Chat</div>
      <div class="topbar-user">
        <div class="avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
        <?= htmlspecialchars($_SESSION['username']) ?>
      </div>
    </div>
    <div class="page-content">
      <div class="chat-layout">

        <!-- LIST ADMIN -->
        <div class="chat-sidebar">
          <div class="chat-sidebar-title">Admin</div>
          <?php while($a = mysqli_fetch_assoc($admins)): ?>
            <a href="chat.php?with=<?= $a['id'] ?>"
               class="chat-user-item <?= (isset($_GET['with']) && $_GET['with'] == $a['id']) ? 'active' : '' ?>">
              <div class="av"><?= strtoupper(substr($a['username'], 0, 1)) ?></div>
              <div>
                <div class="name"><?= htmlspecialchars($a['username']) ?></div>
                <div class="role-label">Admin</div>
              </div>
            </a>
          <?php endwhile; ?>
        </div>

        <!-- AREA CHAT -->
        <?php if(isset($_GET['with']) && (int)$_GET['with'] > 0):
          $pid = (int)$_GET['with'];
          $partner = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id, username FROM users WHERE id='$pid'"));
        ?>
        <div class="chat-main">
          <div class="chat-header">
            <div class="av"><?= strtoupper(substr($partner['username'], 0, 1)) ?></div>
            <div class="info">
              <div class="name"><?= htmlspecialchars($partner['username']) ?></div>
              <div class="sub">Admin</div>
            </div>
          </div>
          <div class="chat-messages" id="chatBox"></div>
          <div class="chat-input-area">
            <textarea class="chat-input" id="msgInput" placeholder="Ketik pesan..." rows="1"
              onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();kirim();}"></textarea>
            <button class="btn-send" onclick="kirim()">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M22 2L11 13M22 2L15 22l-4-9-9-4 19-7z"/></svg>
            </button>
          </div>
        </div>
        <?php else: ?>
        <div class="chat-main">
          <div class="chat-empty">Pilih admin untuk mulai chat</div>
        </div>
        <?php endif; ?>

      </div>
    </div>
  </div>

  <?php if(isset($_GET['with'])): ?>
  <script>
    const ME      = <?= $uid ?>;
    const PARTNER = <?= (int)$_GET['with'] ?>;
    let lastId    = 0;

    function formatTime(dt) {
      const d = new Date(dt.replace(' ', 'T'));
      return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    }

    function renderChats(chats) {
      const box = document.getElementById('chatBox');
      box.innerHTML = '';
      chats.forEach(c => {
        const wrap = document.createElement('div');
        wrap.className = 'bubble-wrap ' + (c.is_me ? 'me' : 'them');
        wrap.innerHTML = `
          <div class="bubble ${c.is_me ? 'me' : 'them'}">${escHtml(c.message)}</div>
          <div class="bubble-time">${formatTime(c.created_at)}</div>`;
        box.appendChild(wrap);
        lastId = Math.max(lastId, parseInt(c.id));
      });
      box.scrollTop = box.scrollHeight;
    }

    function escHtml(str) {
      return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    function fetchChats() {
      fetch(`../api/chat_fetch.php?with=${PARTNER}`)
        .then(r => r.json())
        .then(data => renderChats(data))
        .catch(() => {});
    }

    function kirim() {
      const input = document.getElementById('msgInput');
      const msg   = input.value.trim();
      if(!msg) return;
      input.value = '';

      const fd = new FormData();
      fd.append('to_id',   PARTNER);
      fd.append('message', msg);

      fetch('../api/chat_send.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(() => fetchChats())
        .catch(() => {});
    }

    fetchChats();
    setInterval(fetchChats, 3000);
  </script>
  <?php endif; ?>
</body>
</html>