<?php
session_start();
include "../config/db.php";

if(!isset($_GET['id'])){
  header("Location: my_tasks.php");
  exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);
$data = mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'");
$row  = mysqli_fetch_assoc($data);

if(!$row){
  echo "Task tidak ditemukan!";
  exit;
}

// Handle tambah target baru saat pending
if(isset($_POST['tambah_target'])) {
  $target_baru = mysqli_real_escape_string($conn, $_POST['target_baru']);
  $assigned_to = mysqli_real_escape_string($conn, $_POST['assigned_to']);
  $catatan     = mysqli_real_escape_string($conn, $_POST['catatan'] ?? '');
  $keterangan  = mysqli_real_escape_string($conn, $_POST['keterangan'] ?? '');

  // Update status jadi Pending + keterangan
  mysqli_query($conn, "UPDATE tasks SET status='Pending', keterangan='$keterangan' WHERE id='$id'");

  // Simpan target baru
  if($target_baru && $assigned_to) {
    mysqli_query($conn, "INSERT INTO task_targets (task_id, target_tanggal, assigned_to, catatan) VALUES ('$id','$target_baru','$assigned_to','$catatan')");
    mysqli_query($conn, "UPDATE tasks SET target_tanggal='$target_baru' WHERE id='$id'");
  }

  header("Location: my_tasks.php?updated=1");
  exit;
}

// Handle update biasa (Closed)
if(isset($_POST['update'])){
  $status     = mysqli_real_escape_string($conn, $_POST['update']);
  $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
  mysqli_query($conn, "UPDATE tasks SET status='$status', keterangan='$keterangan' WHERE id='$id'");
  header("Location: my_tasks.php?updated=1");
  exit;
}

// Ambil semua user untuk dropdown
$all_users = mysqli_query($conn, "SELECT id, username FROM users ORDER BY username ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Task</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'DM Sans', sans-serif;
  background: #f5f6fa;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding: 20px;
}
.card {
  width: 100%;
  max-width: 520px;
  background: #fff;
  border-radius: 18px;
  padding: 28px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.08);
}
.card h2 {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.4rem;
  margin-bottom: 15px;
}
.info { font-size: 0.85rem; margin-bottom: 10px; color: #555; }
textarea, input[type="date"], select {
  width: 100%;
  border-radius: 10px;
  border: 1px solid #ddd;
  padding: 10px;
  font-size: 0.85rem;
  outline: none;
  font-family: 'DM Sans', sans-serif;
  box-sizing: border-box;
}
textarea { height: 110px; resize: vertical; }
textarea:focus, input[type="date"]:focus, select:focus { border-color: #f59e0b; }

.btn-group { display: flex; gap: 10px; margin-top: 15px; }
.btn {
  flex: 1; border: none; border-radius: 10px;
  padding: 10px; font-size: 0.8rem; font-weight: 700; cursor: pointer;
}
.btn-close  { background: linear-gradient(135deg,#22c55e,#16a34a); color: #fff; }
.btn-pending{ background: linear-gradient(135deg,#f59e0b,#d97706); color: #fff; }
.btn-back   { margin-top: 10px; display: block; text-align: center; font-size: 0.75rem; color: #888; text-decoration: none; }

/* Panel target baru */
.pending-panel {
  display: none;
  margin-top: 20px;
  border: 1.5px solid rgba(245,158,11,0.4);
  border-radius: 12px;
  background: rgba(245,158,11,0.05);
  padding: 18px;
}
.pending-panel.show { display: block; }
.pending-panel .panel-title {
  font-family: 'Syne', sans-serif;
  font-size: 0.9rem;
  font-weight: 700;
  color: #d97706;
  margin-bottom: 14px;
}
.form-group { margin-bottom: 12px; }
.form-group label { display: block; font-size: 0.78rem; font-weight: 600; color: #555; margin-bottom: 5px; }

.btn-submit-pending {
  width: 100%; border: none; border-radius: 10px;
  padding: 10px; font-size: 0.85rem; font-weight: 700;
  cursor: pointer; margin-top: 4px;
  background: linear-gradient(135deg,#f59e0b,#d97706);
  color: #fff;
}
.btn-submit-pending:hover { opacity: 0.9; }
</style>
</head>
<body>

<div class="card">
  <h2>Update Task #<?= $row['id'] ?></h2>
  <div class="info"><b>Pelapor:</b> <?= htmlspecialchars($row['nama']) ?></div>
  <div class="info"><b>Task:</b> <?= htmlspecialchars($row['todo']) ?></div>
  <div class="info"><b>Status:</b> <?= $row['status'] ?></div>

  <!-- Form utama: Selesaikan / Pending -->
  <form method="POST" id="formUtama">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">
    <textarea name="keterangan" id="keteranganUtama"
      placeholder="Isi keterangan pekerjaan..."><?= htmlspecialchars($row['keterangan'] ?? '') ?></textarea>

    <div class="btn-group">
      <button type="submit" name="update" value="Closed" class="btn btn-close">✔ Selesaikan</button>
      <!-- Tombol Pending tidak submit, tapi tampilkan panel -->
      <button type="button" class="btn btn-pending" onclick="tampilkanPending()">⏳ Pending</button>
    </div>
  </form>

  <!-- Panel Target Baru (muncul saat klik Pending) -->
  <div class="pending-panel" id="pendingPanel">
    <div class="panel-title">⏳ Tambah Target Baru</div>
    <form method="POST" id="formPending">
      <input type="hidden" name="id" value="<?= $row['id'] ?>">
      <!-- Keterangan ikut dikirim dari field utama via JS -->
      <input type="hidden" name="keterangan" id="keteranganHidden">

      <div class="form-group">
        <label>Target Tanggal Baru</label>
        <input type="date" name="target_baru" required min="<?= date('Y-m-d') ?>">
      </div>

  <a href="my_tasks.php" class="btn-back">← Kembali</a>
</div>

<script>
function tampilkanPending() {
  // Salin keterangan dari form utama ke hidden input
  document.getElementById('keteranganHidden').value =
    document.getElementById('keteranganUtama').value;
  document.getElementById('pendingPanel').classList.add('show');
}
function sembunyikanPending() {
  document.getElementById('pendingPanel').classList.remove('show');
}
</script>
</body>
</html>