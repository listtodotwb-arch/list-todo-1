<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['username']) || $_SESSION['role'] !== 'user'){
  header("Location: ../auth/login.php");
  exit;
}

$me  = mysqli_real_escape_string($conn, $_SESSION['username']);
$uid = $_SESSION['user_id'] ?? 0;

// TANDAI SELESAI
if(isset($_POST['selesai'])) {
  $tid = mysqli_real_escape_string($conn, $_POST['task_id']);
  mysqli_query($conn, "UPDATE tasks SET status='Closed' WHERE id='$tid' AND nama='$me'");
  header("Location: my_tasks.php?done=1");
  exit;
}

$where = "WHERE t.nama = '$me'";
if(!empty($_GET['status']))  $where .= " AND t.status = '".mysqli_real_escape_string($conn,$_GET['status'])."'";
if(!empty($_GET['urgency'])) $where .= " AND t.urgency = '".mysqli_real_escape_string($conn,$_GET['urgency'])."'";
if(!empty($_GET['search']))  $where .= " AND t.todo LIKE '%".mysqli_real_escape_string($conn,$_GET['search'])."%'";

// JOIN task_targets: ambil target terbaru yang di-assign ke user ini
$data = mysqli_query($conn,"
  SELECT t.*,
    (SELECT tt.target_tanggal FROM task_targets tt 
     WHERE tt.task_id = t.id AND tt.assigned_to = '$uid'
     ORDER BY tt.created_at DESC LIMIT 1) AS target_terbaru,
    (SELECT tt.catatan FROM task_targets tt 
     WHERE tt.task_id = t.id AND tt.assigned_to = '$uid'
     ORDER BY tt.created_at DESC LIMIT 1) AS catatan_terbaru
  FROM tasks t
  $where
  ORDER BY t.created_at DESC
");

$total   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tasks WHERE nama='$me'"))['c'];
$open    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tasks WHERE nama='$me' AND status='Open'"))['c'];
$pending = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tasks WHERE nama='$me' AND status='Pending'"))['c'];
$late    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tasks WHERE nama='$me' AND status='Late'"))['c'];
$done    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tasks WHERE nama='$me' AND status='Closed'"))['c'];

$unread = 0;
if($uid) {
  $unread = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n'];
}

$activeStatus = $_GET['status'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Tasks — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .popup-overlay.popup-hidden { display:none !important; }

    /* ── WELCOME BAR ── */
    .welcome-bar {
      background: linear-gradient(135deg, #9E86A8 0%, #9FBB3C 100%);
      border-radius: 14px;
      padding: 18px 24px;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      gap: 14px;
    }
    .welcome-bar .wb-icon {
      width: 40px; height: 40px;
      background: rgba(255,255,255,0.2);
      border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
    }
    .welcome-bar .wb-icon svg { width: 20px; height: 20px; color: #fff; }
    .welcome-bar .wb-text h3 {
      font-family: 'Syne', sans-serif;
      font-size: 1rem; font-weight: 700;
      color: #fff; margin-bottom: 2px;
    }
    .welcome-bar .wb-text p { font-size: 0.78rem; color: rgba(255,255,255,0.75); }

    /* ── SEARCH BAR ── */
    .top-search-wrap {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 16px;
    }
    .top-search-inner {
      position: relative;
      flex: 1;
      max-width: 340px;
    }
    .top-search-inner svg {
      position: absolute;
      left: 11px; top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
    }
    .top-search-inner input {
      width: 100%;
      padding: 9px 14px 9px 34px;
      border: 1.5px solid #e5e7eb;
      border-radius: 10px;
      font-size: 0.82rem;
      background: #fff;
      color: #374151;
      outline: none;
      transition: border 0.18s;
      box-sizing: border-box;
    }
    .top-search-inner input:focus { border-color: #9FBB3C; }
    .btn-search {
      background: #9FBB3C;
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 9px 18px;
      font-size: 0.82rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.18s;
      white-space: nowrap;
    }
    .btn-search:hover { background: #8aaa2e; }
    .btn-reset-top {
      display: inline-flex; align-items: center; gap: 5px;
      color: #9ca3af; font-size: 0.78rem; font-weight: 600;
      text-decoration: none; padding: 7px 10px;
      border-radius: 8px; border: 1.5px solid #e5e7eb;
      background: #fff; transition: color 0.15s, border-color 0.15s;
      white-space: nowrap;
    }
    .btn-reset-top:hover { color: #ef4444; border-color: #ef4444; }

    /* ── STAT CARDS ── */
    .stat-row {
      display: flex;
      gap: 14px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .stat-card {
      flex: 1;
      min-width: 110px;
      background: #fff;
      border-radius: 14px;
      padding: 16px 18px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
      border: 2px solid transparent;
      border-left: 4px solid #e5e7eb;
      cursor: pointer;
      text-decoration: none;
      display: block;
      transition: transform 0.15s, box-shadow 0.15s, border-color 0.15s;
      position: relative;
    }
    .stat-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.10);
    }
    .stat-card.open    { border-left-color: #3b82f6; }
    .stat-card.pending { border-left-color: #f59e0b; }
    .stat-card.late    { border-left-color: #9E86A8; }
    .stat-card.closed  { border-left-color: #22c55e; }

    .stat-card.open.active    { border-color: #3b82f6; background: #eff6ff; }
    .stat-card.pending.active { border-color: #f59e0b; background: #fffbeb; }
    .stat-card.late.active    { border-color: #9E86A8; background: #f5f3ff; }
    .stat-card.closed.active  { border-color: #22c55e; background: #f0fdf4; }

    .stat-card .s-num {
      font-family: 'Syne', sans-serif;
      font-size: 1.9rem; font-weight: 800;
      line-height: 1; margin-bottom: 4px;
    }
    .stat-card.open    .s-num { color: #3b82f6; }
    .stat-card.pending .s-num { color: #f59e0b; }
    .stat-card.late    .s-num { color: #9E86A8; }
    .stat-card.closed  .s-num { color: #22c55e; }
    .stat-card .s-label {
      font-size: 0.70rem; font-weight: 600;
      text-transform: uppercase; letter-spacing: 0.8px; color: #9ca3af;
    }
    .stat-card .active-dot {
      display: none;
      position: absolute; top: 10px; right: 10px;
      width: 8px; height: 8px; border-radius: 50%;
    }
    .stat-card.open.active    .active-dot { display: block; background: #3b82f6; }
    .stat-card.pending.active .active-dot { display: block; background: #f59e0b; }
    .stat-card.late.active    .active-dot { display: block; background: #9E86A8; }
    .stat-card.closed.active  .active-dot { display: block; background: #22c55e; }

    /* ── FILTER BAR ── */
    .filter-bar-slim {
      display: flex;
      gap: 10px;
      align-items: center;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }
    .filter-label-sm {
      font-size: 0.75rem; font-weight: 600;
      color: #9ca3af; text-transform: uppercase; letter-spacing: 0.6px;
    }

    /* ── MISC ── */
    .empty-state {
      text-align: center; padding: 60px 20px; color: #9ca3af;
    }
    .empty-state svg { width: 48px; height: 48px; margin: 0 auto 16px; opacity: 0.4; }
    .empty-state p { font-size: 0.9rem; }
    .btn-selesai {
      display: inline-flex; align-items: center; gap: 5px;
      background: rgba(34,197,94,0.14);
      border: 1px solid rgba(34,197,94,0.3);
      border-radius: 7px; color: #22c55e;
      font-size: 0.75rem; font-weight: 700;
      padding: 5px 11px; cursor: pointer; transition: background 0.18s;
      text-decoration: none;
    }
    .btn-selesai:hover { background: rgba(34,197,94,0.28); }
    .badge-unread {
      display: inline-flex; align-items: center; justify-content: center;
      background: #ef4444; color: #fff; border-radius: 99px;
      font-size: 0.6rem; font-weight: 800;
      min-width: 16px; height: 16px; padding: 0 4px; margin-left: 4px;
    }
    .toast {
      position: fixed; bottom: 24px; right: 24px;
      background: rgba(34,197,94,0.15);
      border: 1px solid rgba(34,197,94,0.3); color: #22c55e;
      padding: 10px 18px; border-radius: 8px;
      font-size: 0.83rem; font-weight: 500;
      z-index: 9999; animation: fadeInUp 0.25s ease;
    }
    @keyframes fadeInUp {
      from { opacity:0; transform:translateY(10px); }
      to   { opacity:1; transform:translateY(0); }
    }
    /* badge target baru */
    .badge-target-baru {
      display: inline-block;
      background: rgba(245,158,11,0.15);
      color: #f59e0b;
      border: 1px solid rgba(245,158,11,0.3);
      border-radius: 5px;
      font-size: 0.68rem;
      font-weight: 700;
      padding: 1px 6px;
      margin-left: 4px;
    }
  </style>
</head>
<body>

  <?php if(isset($_GET['done'])): ?>
    <div class="toast" id="toast">Task berhasil ditandai selesai!</div>
  <?php endif; ?>

  <!-- POPUP KONFIRMASI SELESAI -->
  <div class="popup-overlay popup-hidden" id="popupSelesai">
    <div class="popup-box" id="popupSelesaiBox">
      <div class="popup-icon">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
          <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
        </svg>
      </div>
      <div class="popup-title">Tandai Selesai?</div>
      <div class="popup-msg">Yakin task ini sudah selesai dikerjakan? Status akan berubah jadi <strong style="color:#22c55e">Closed</strong>.</div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-secondary" onclick="tutupSelesai()">Batal</button>
        <button class="popup-btn popup-btn-primary" onclick="submitSelesai()">Ya, Selesai</button>
      </div>
    </div>
  </div>

  <form method="POST" id="formSelesai" style="display:none;">
    <input type="hidden" name="task_id" id="inputTaskId">
    <input type="hidden" name="selesai" value="1">
  </form>

  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">User Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="my_tasks.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        My Tasks
      </a>
      <a href="chat.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat
        <?php if($unread > 0): ?>
          <span class="badge-unread"><?= $unread ?></span>
        <?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>
        Logout
      </a>
    </div>
  </div>

  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">My Tasks</div>
      <div class="topbar-user"><?= htmlspecialchars($_SESSION['username']) ?></div>
    </div>
    <div class="page-content">

      <!-- WELCOME BAR -->
      <div class="welcome-bar">
        <div class="wb-icon">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
        </div>
        <div class="wb-text">
          <h3>Halo, <?= htmlspecialchars($_SESSION['username']) ?>!</h3>
          <p>Ini Semua Task Anda.</p>
        </div>
      </div>

      <!-- SEARCH BAR -->
      <form method="GET" id="mainForm">
        <input type="hidden" name="status"  id="hiddenStatus"  value="<?= htmlspecialchars($activeStatus) ?>">
        <input type="hidden" name="urgency" id="hiddenUrgency" value="<?= htmlspecialchars($_GET['urgency'] ?? '') ?>">

        <div class="top-search-wrap">
          <div class="top-search-inner">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#9ca3af" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/>
            </svg>
            <input type="text" name="search" placeholder="Cari task..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
          </div>
          <button type="submit" class="btn-search">Cari</button>
          <?php if(!empty($_GET['search']) || !empty($activeStatus) || !empty($_GET['urgency'])): ?>
            <a href="my_tasks.php" class="btn-reset-top">
              <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
              Reset
            </a>
          <?php endif; ?>
        </div>
      </form>

      <!-- STAT CARDS -->
      <div class="stat-row">
        <?php
          $cards = [
            ['type'=>'open',    'status'=>'Open',    'count'=>$open,    'label'=>'Open'],
            ['type'=>'pending', 'status'=>'Pending', 'count'=>$pending, 'label'=>'Pending'],
            ['type'=>'late',    'status'=>'Late',    'count'=>$late,    'label'=>'Late'],
            ['type'=>'closed',  'status'=>'Closed',  'count'=>$done,    'label'=>'Done'],
          ];
          foreach($cards as $c):
            $isActive = ($activeStatus === $c['status']);
            $href = $isActive
              ? 'my_tasks.php' . (!empty($_GET['search']) ? '?search='.urlencode($_GET['search']) : '')
              : '?status='.urlencode($c['status'])
                .(!empty($_GET['search'])  ? '&search='.urlencode($_GET['search'])   : '')
                .(!empty($_GET['urgency']) ? '&urgency='.urlencode($_GET['urgency']) : '');
        ?>
        <a href="<?= $href ?>"
           class="stat-card <?= $c['type'] ?><?= $isActive ? ' active' : '' ?>"
           title="<?= $isActive ? 'Klik untuk reset filter' : 'Filter: '.$c['label'] ?>">
          <div class="active-dot"></div>
          <div class="s-num"><?= $c['count'] ?></div>
          <div class="s-label"><?= $c['label'] ?></div>
        </a>
        <?php endforeach; ?>
      </div>

      <!-- FILTER URGENCY -->
      <form method="GET" class="filter-bar-slim">
        <input type="hidden" name="status" value="<?= htmlspecialchars($activeStatus) ?>">
        <input type="hidden" name="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        <span class="filter-label-sm">Urgency:</span>
        <select name="urgency" class="filter-select" onchange="this.form.submit()">
          <option value="">Semua</option>
          <option value="Low"    <?= ($_GET['urgency']??'')==='Low'    ? 'selected':'' ?>>Low</option>
          <option value="Medium" <?= ($_GET['urgency']??'')==='Medium' ? 'selected':'' ?>>Medium</option>
          <option value="High"   <?= ($_GET['urgency']??'')==='High'   ? 'selected':'' ?>>High</option>
        </select>
      </form>

      <!-- TABLE -->
      <div class="table-wrap">
        <?php $rows = mysqli_num_rows($data); ?>
        <?php if($rows === 0): ?>
          <div class="empty-state">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            <p>Tidak ada task yang ditemukan.</p>
          </div>
        <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Urgency</th>
              <th>Task</th>
              <th>Departemen</th>
              <th>Divisi</th>
              <th>Keterangan</th>
              <th>Status</th>
              <th>Target Tanggal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
<?php while($row = mysqli_fetch_assoc($data)): 
  // Tentukan tanggal yang ditampilin: target_terbaru (dari task_targets) kalau ada, fallback ke target_tanggal di tasks
  $tanggal_tampil = !empty($row['target_terbaru']) ? $row['target_terbaru'] : $row['target_tanggal'];
  // Keterangan: catatan dari task_targets kalau ada, fallback ke keterangan di tasks
  $ket_tampil = !empty($row['catatan_terbaru']) ? $row['catatan_terbaru'] : ($row['keterangan'] ?? '');
?>
<tr>
  <td><?= $row['id'] ?></td>
  <td>
    <?php
      $u  = strtolower($row['urgency']);
      $uc = $u === 'high' ? '#ef4444' : ($u === 'medium' ? '#f59e0b' : '#22c55e');
    ?>
    <span class="urgency-badge" style="color:<?= $uc ?>;"><?= $row['urgency'] ?></span>
  </td>
  <td><?= htmlspecialchars($row['todo']) ?></td>
  <td><?= htmlspecialchars($row['departemen']) ?></td>
  <td><?= htmlspecialchars($row['DIVISI'] ?? $row['divisi'] ?? '') ?></td>
  <td>
    <?= htmlspecialchars($ket_tampil) ?>
    <?php if(!empty($row['catatan_terbaru'])): ?>
      <span class="badge-target-baru">Baru</span>
    <?php endif; ?>
  </td>
  <td>
    <span class="badge badge-<?= strtolower($row['status']) ?>"><?= $row['status'] ?></span>
  </td>
  <td>
    <?php if($tanggal_tampil): ?>
      <?= date('d M Y', strtotime($tanggal_tampil)) ?>
      <?php if(!empty($row['target_terbaru'])): ?>
        <span class="badge-target-baru">Update</span>
      <?php endif; ?>
    <?php else: ?>
      <span style="color:#9ca3af;font-size:0.75rem;">-</span>
    <?php endif; ?>
  </td>
  <td>
    <?php if($row['status'] !== 'Closed'): ?>
      <a href="update_task.php?id=<?= $row['id'] ?>" class="btn-selesai">✏️ Kerjakan</a>
    <?php else: ?>
      <span style="color:#22c55e;font-size:0.75rem;font-weight:700;">✓ Done</span>
    <?php endif; ?>
  </td>
</tr>
<?php endwhile; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>

    </div>
  </div>

  <script>
    function konfirmSelesai(id) {
      document.getElementById('inputTaskId').value = id;
      const overlay = document.getElementById('popupSelesai');
      overlay.classList.remove('popup-hidden', 'hide');
      document.getElementById('popupSelesaiBox').classList.remove('hide');
    }
    function tutupSelesai() {
      const overlay = document.getElementById('popupSelesai');
      const box     = document.getElementById('popupSelesaiBox');
      box.classList.add('hide');
      overlay.classList.add('hide');
      setTimeout(() => overlay.classList.add('popup-hidden'), 220);
    }
    function submitSelesai() {
      document.getElementById('formSelesai').submit();
    }
    document.getElementById('popupSelesai').addEventListener('click', function(e) {
      if(e.target === this) tutupSelesai();
    });

    const toast = document.getElementById('toast');
    if(toast) setTimeout(() => {
      toast.style.transition = 'opacity 0.4s';
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 400);
    }, 3000);
  </script>
</body>
</html>