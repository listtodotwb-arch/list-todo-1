<?php
session_start();
include "../config/db.php";

if(isset($_POST['login'])){
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  $q = mysqli_query($conn,"
    SELECT * FROM users
    WHERE username='$username'
    AND password='$password'
  ");

  $data = mysqli_fetch_assoc($q);

  if($data){
    $_SESSION['username'] = $data['username'];
    $_SESSION['role']     = $data['role'];
    $_SESSION['user_id']  = $data['id'];

    if($data['role'] == "admin"){
      header("Location: ../admin/dashboard.php");
    } else {
      header("Location: ../user/my_tasks.php");
    }
    exit;
  } else {
    $error = "Username atau password salah!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — To Do List</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --hijau: #9FBB3C;
      --ungu: #9E86A8;
      --ungu-dark: #7a6588;
      --ungu-light: #f0ecf4;
      --ungu-mid: #c4b4d0;
    }

    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: var(--ungu-light);
      overflow: hidden;
      position: relative;
    }

    body::before {
      content: '';
      position: fixed;
      top: -120px; left: -120px;
      width: 480px; height: 480px;
      background: radial-gradient(circle, rgba(158,134,168,0.35) 0%, transparent 70%);
      border-radius: 50%;
      animation: float 8s ease-in-out infinite;
    }

    body::after {
      content: '';
      position: fixed;
      bottom: -100px; right: -80px;
      width: 420px; height: 420px;
      background: radial-gradient(circle, rgba(159,187,60,0.25) 0%, transparent 70%);
      border-radius: 50%;
      animation: float 11s ease-in-out infinite reverse;
    }

    @keyframes float {
      0%, 100% { transform: translate(0, 0) scale(1); }
      50% { transform: translate(30px, 30px) scale(1.05); }
    }

    .bg-dots {
      position: fixed;
      inset: 0;
      background-image: radial-gradient(circle, rgba(158,134,168,0.2) 1.5px, transparent 1.5px);
      background-size: 28px 28px;
      pointer-events: none;
      z-index: 0;
    }

    .wrapper {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: stretch;
      width: 860px;
      max-width: 95vw;
      border-radius: 24px;
      overflow: hidden;
      box-shadow: 0 32px 80px rgba(100,70,130,0.18), 0 8px 24px rgba(100,70,130,0.1);
      animation: slideUp 0.6s cubic-bezier(0.16,1,0.3,1) both;
    }

    @keyframes slideUp {
      from { opacity: 0; transform: translateY(40px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .panel-left {
      width: 42%;
      background: linear-gradient(145deg, var(--ungu) 0%, var(--ungu-dark) 60%, #5c4470 100%);
      padding: 52px 40px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      overflow: hidden;
    }

    .panel-left::before {
      content: '';
      position: absolute;
      top: -60px; right: -60px;
      width: 220px; height: 220px;
      background: rgba(255,255,255,0.06);
      border-radius: 50%;
    }

    .panel-left::after {
      content: '';
      position: absolute;
      bottom: -40px; left: -40px;
      width: 180px; height: 180px;
      background: rgba(159,187,60,0.12);
      border-radius: 50%;
    }

    .brand {
      position: relative;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center; /* Logo & teks terpusat */
      text-align: center;
    }

    .brand-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(255,255,255,0.12);
      border: 1px solid rgba(255,255,255,0.2);
      border-radius: 99px;
      padding: 5px 14px 5px 8px;
      margin-bottom: 24px;
      align-self: flex-start; /* Badge tetap di kiri */
    }

    .brand-dot {
      width: 8px; height: 8px;
      background: var(--hijau);
      border-radius: 50%;
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.6; transform: scale(0.85); }
    }

    .brand-badge span {
      font-size: 0.72rem;
      font-weight: 600;
      color: rgba(255,255,255,0.85);
      letter-spacing: 0.5px;
    }

    /* ===== LOGO — FIX UTAMA ===== */
    .logo {
      width: 110px;
      height: 110px;
      object-fit: contain;
      display: block;
      margin: 0 auto 20px auto; /* tengah horizontal, jarak bawah ke teks */
      opacity: 0.88;
      position: static; /* hapus absolute */
      filter: drop-shadow(0 4px 16px rgba(0,0,0,0.18));
    }
    /* ============================= */

    .brand h1 {
      font-size: 2rem;
      font-weight: 800;
      color: #fff;
      line-height: 1.15;
      margin-bottom: 12px;
    }

    .brand h1 span { color: var(--hijau); }

    .brand p {
      font-size: 0.85rem;
      color: rgba(255,255,255,0.6);
      line-height: 1.6;
      font-weight: 400;
    }

    .panel-left-footer { position: relative; z-index: 1; }

    .stats { display: flex; gap: 20px; }
    .stat-item { text-align: left; }
    .stat-num {
      font-size: 1.4rem;
      font-weight: 800;
      color: var(--hijau);
      line-height: 1;
    }
    .stat-label {
      font-size: 0.68rem;
      color: rgba(255,255,255,0.5);
      font-weight: 500;
      margin-top: 3px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .panel-right {
      flex: 1;
      background: #fff;
      padding: 52px 44px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .form-header { margin-bottom: 32px; }

    .form-header h2 {
      font-size: 1.5rem;
      font-weight: 800;
      color: #2d1f3d;
      margin-bottom: 6px;
    }

    .form-header p {
      font-size: 0.83rem;
      color: #9E86A8;
      font-weight: 400;
    }

    .error-box {
      background: rgba(239,68,68,0.06);
      border: 1px solid rgba(239,68,68,0.25);
      border-radius: 10px;
      padding: 10px 14px;
      margin-bottom: 20px;
      font-size: 0.82rem;
      color: #ef4444;
      font-weight: 500;
    }

    .form-group { margin-bottom: 18px; }

    .form-group label {
      display: block;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #9E86A8;
      margin-bottom: 7px;
    }

    .input-wrap { position: relative; }

    .input-wrap svg {
      position: absolute;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      width: 16px; height: 16px;
      color: #c4b4d0;
      pointer-events: none;
    }

    .form-group input {
      width: 100%;
      background: var(--ungu-light);
      border: 1.5px solid #e2d9ec;
      border-radius: 10px;
      color: #2d1f3d;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 0.9rem;
      font-weight: 500;
      padding: 12px 14px 12px 40px;
      outline: none;
      transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
    }

    .form-group input::placeholder { color: #c4b4d0; }

    .form-group input:focus {
      border-color: var(--ungu);
      background: #fff;
      box-shadow: 0 0 0 3px rgba(158,134,168,0.15);
    }

    .btn-login {
      width: 100%;
      background: linear-gradient(135deg, var(--ungu) 0%, var(--hijau) 100%);
      border: none;
      border-radius: 10px;
      color: #fff;
      cursor: pointer;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 0.92rem;
      font-weight: 700;
      padding: 13px;
      margin-top: 8px;
      letter-spacing: 0.3px;
      transition: opacity 0.2s, transform 0.15s, box-shadow 0.2s;
      box-shadow: 0 6px 20px rgba(158,134,168,0.4);
    }

    .btn-login:hover {
      opacity: 0.9;
      transform: translateY(-1px);
      box-shadow: 0 10px 28px rgba(158,134,168,0.5);
    }

    .btn-login:active { transform: translateY(0); }

    @media (max-width: 640px) {
      .panel-left { display: none; }
      .panel-right { padding: 40px 28px; }
      .wrapper { border-radius: 20px; }
    }
  </style>
</head>
<body>

<div class="bg-dots"></div>

<div class="wrapper">
  <div class="panel-left">
    <div class="brand">
      <div class="brand-badge">
        <div class="brand-dot"></div>
        <span>Sistem Aktif</span>
      </div>
      <img src="../assets/logo.png" class="logo" alt="Logo TWB">
      <h1>To Do<br><span>List</span></h1>
    </div>
    <div class="panel-left-footer">
      <div class="stats">
        <div class="stat-item">
          <div class="stat-num"></div>
          <div class="stat-label"></div>
        </div>
        <div class="stat-item">
          <div class="stat-num"></div>
          <div class="stat-label"></div>
        </div>
      </div>
    </div>
  </div>

  <div class="panel-right">
    <div class="form-header">
      <h2>Selamat datang</h2>
    </div>

    <?php if(isset($error)): ?>
      <div class="error-box"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <div class="input-wrap">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
          <input type="text" name="username" placeholder="Username anda" required>
        </div>
      </div>

      <div class="form-group">
        <label>Password</label>
        <div class="input-wrap">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
          <input type="password" name="password" placeholder="Password anda" required>
        </div>
      </div>

      <button class="btn-login" name="login" type="submit">Masuk Sekarang</button>
    </form>
  </div>
</div>

</body>
</html>