<?php
session_start();
include "../config/db.php";

$users = mysqli_query($conn,"SELECT * FROM users WHERE role='user'");

$showPopup = false;
if(isset($_POST['save'])){
  $nama    = mysqli_real_escape_string($conn, $_POST['nama']);
  $urgency = mysqli_real_escape_string($conn, $_POST['urgency']);
  $todo    = mysqli_real_escape_string($conn, $_POST['todo']);
  $dept    = mysqli_real_escape_string($conn, $_POST['departemen']);
  $target  = mysqli_real_escape_string($conn, $_POST['target_tanggal']);
  $divisi  = mysqli_real_escape_string($conn, $_POST['jabatan']);

  $file = $_FILES['file']['name'] ?? '';
  $tmp  = $_FILES['file']['tmp_name'] ?? '';
  if($file) move_uploaded_file($tmp, "../uploads/" . $file);
  $file = mysqli_real_escape_string($conn, $file);

mysqli_query($conn,"INSERT INTO tasks 
(created_at, nama, urgency, todo, target_tanggal, departemen, DIVISI, file, status) 
VALUES 
(NOW(), '$nama', '$urgency', '$todo', '$target', '$dept', '$divisi', '$file', 'Open')");
  $showPopup = true;
}

$uid    = $_SESSION['user_id'] ?? 0;
$unread = $uid ? mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n'] : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buat Task — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .badge-unread{display:inline-flex;align-items:center;justify-content:center;background:#ef4444;color:#fff;border-radius:99px;font-size:0.6rem;font-weight:800;min-width:16px;height:16px;padding:0 4px;margin-left:4px;}
  </style>
</head>
<body>

  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="../admin/dashboard.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9.75L12 3l9 6.75V21H3V9.75z"/></svg>
        Dashboard
      </a>
      <a href="../admin/tasks.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        Semua Task
      </a>
      <a href="create_task.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Buat Task
      </a>
      <a href="../admin/manage_users.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a4 4 0 00-5-3.87M9 20H4v-2a4 4 0 015-3.87m6-4a4 4 0 11-8 0 4 4 0 018 0zm6 4a2 2 0 11-4 0 2 2 0 014 0zM5 16a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        Manage Users
      </a>
      <a href="../admin/chat.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat<?php if($unread>0): ?><span class="badge-unread"><?= $unread ?></span><?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>
        Logout
      </a>
    </div>
  </div>

  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">Buat Task</div>
      <div class="topbar-user"></div>
    </div>
    <div class="page-content">
      <div class="form-card">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label>Pilih User</label>
            <select name="nama" id="pilihUser" required onchange="isiDataUser(this)">
              <option value="">-- Pilih User --</option>
              <?php while($u = mysqli_fetch_assoc($users)): ?>
                <option
                  value="<?= htmlspecialchars($u['username']) ?>"
                  data-departemen="<?= htmlspecialchars($u['departemen'] ?? '') ?>"
                  data-divisi="<?= htmlspecialchars($u['divisi'] ?? '') ?>"
                  data-jabatan="<?= htmlspecialchars($u['jabatan'] ?? '') ?>">
                  <?= htmlspecialchars($u['username']) ?>
                  <?= !empty($u['departemen']) ? ' | '.htmlspecialchars($u['departemen']) : '' ?>
                  <?= !empty($u['divisi'])     ? ' — '.htmlspecialchars($u['divisi'])     : '' ?>
                  <?= !empty($u['jabatan'])    ? ' ('.htmlspecialchars($u['jabatan']).')' : '' ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>
          <input type="hidden" name="departemen" id="fieldDepartemen">
          <input type="hidden" name="jabatan"    id="fieldDivisi">

          <div class="form-group">
            <label>Urgency</label>
            <select name="urgency">
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>
          </div>

          <div class="form-group">
            <label>Task</label>
            <textarea name="todo" placeholder="Deskripsi task..."></textarea>
          </div>
          <div class="form-group">
  <label>Target Tanggal Task</label>
  <style>.form-group input,
.form-group select,
.form-group textarea,
.form-group input[type="date"] {
  width: 100%;
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid #374151;
  background: #111827;
  color: #ffffff;
  font-size: 14px;
}input[type="date"]::-webkit-calendar-picker-indicator {
  filter: invert(1);
  cursor: pointer;
}</style>
  <input type="date" name="target_tanggal" required>
</div>

          <button class="btn-save" name="save" type="submit">Simpan Task</button>
        </form>
      </div>
    </div>
  </div>

  <?php if($showPopup): ?>
  <div class="popup-overlay" id="popup">
    <div class="popup-box" id="popupBox">
      <div class="popup-icon">
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
      </div>
      <div class="popup-title">Task Berhasil Dibuat!</div>
      <div class="popup-msg">Task sudah tersimpan ke database.</div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-secondary" onclick="window.location.href='create_task.php'">Buat Lagi</button>
        <button class="popup-btn popup-btn-primary"   onclick="window.location.href='../admin/tasks.php'">Lihat Semua Task</button>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <script>
    function isiDataUser(sel) {
      const opt = sel.options[sel.selectedIndex];
      document.getElementById('fieldDepartemen').value = opt.dataset.departemen || '';
      document.getElementById('fieldDivisi').value     = opt.dataset.divisi     || '';
    }
  </script>

</body>
</html>