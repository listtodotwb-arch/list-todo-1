<?php
session_start();
include "../config/db.php";

// ── Tambah ──
if(isset($_POST['tambah_departemen'])){
  $nama=$conn->real_escape_string($_POST['nama_departemen']);
  mysqli_query($conn,"INSERT INTO departemen (nama) VALUES ('$nama')");
  $kelola_popup = ['type'=>'tambah','kat'=>'Departemen','nama'=>$nama];
}
if(isset($_POST['tambah_divisi'])){
  $nama=$conn->real_escape_string($_POST['nama_divisi']);
  mysqli_query($conn,"INSERT INTO divisi (nama) VALUES ('$nama')");
  $kelola_popup = ['type'=>'tambah','kat'=>'Divisi','nama'=>$nama];
}
if(isset($_POST['tambah_jabatan'])){
  $nama=$conn->real_escape_string($_POST['nama_jabatan']);
  mysqli_query($conn,"INSERT INTO jabatan (nama) VALUES ('$nama')");
  $kelola_popup = ['type'=>'tambah','kat'=>'Jabatan','nama'=>$nama];
}

// ── Edit user ──
if(isset($_POST['tambah'])) {
  $username=$conn->real_escape_string($_POST['username']);
  $password=md5($_POST['password']);
  $role=$conn->real_escape_string($_POST['role']);
  $departemen=$conn->real_escape_string($_POST['departemen']);
  $divisi=$conn->real_escape_string($_POST['divisi']);
  $jabatan=$conn->real_escape_string($_POST['jabatan']);
  mysqli_query($conn,"INSERT INTO users (username,password,role,departemen,divisi,jabatan) VALUES ('$username','$password','$role','$departemen','$divisi','$jabatan')");
  $popup_type='tambah'; $popup_username=$username;
}
if(isset($_POST['edit'])) {
  $id=$conn->real_escape_string($_POST['id']);
  $username=$conn->real_escape_string($_POST['username']);
  $role=$conn->real_escape_string($_POST['role']);
  $departemen=$conn->real_escape_string($_POST['departemen']);
  $divisi=$conn->real_escape_string($_POST['divisi']);
  $jabatan=$conn->real_escape_string($_POST['jabatan']);
  $passQuery="";
  if(!empty($_POST['password'])){$password=md5($_POST['password']);$passQuery=", password='$password'";}
  mysqli_query($conn,"UPDATE users SET username='$username', role='$role', departemen='$departemen', divisi='$divisi', jabatan='$jabatan'$passQuery WHERE id='$id'");
  $popup_type='edit'; $popup_username=$username;
}

// ── Edit dept/divisi/jabatan ──
if(isset($_POST['edit_departemen'])){
  $id=$_POST['id']; $nama=$_POST['nama_departemen'];
  mysqli_query($conn,"UPDATE departemen SET nama='$nama' WHERE id='$id'");
}
if(isset($_POST['edit_divisi'])){
  $id=$_POST['id']; $nama=$_POST['nama_divisi'];
  mysqli_query($conn,"UPDATE divisi SET nama='$nama' WHERE id='$id'");
}
if(isset($_POST['edit_jabatan'])){
  $id=$_POST['id']; $nama=$_POST['nama_jabatan'];
  mysqli_query($conn,"UPDATE jabatan SET nama='$nama' WHERE id='$id'");
}

// ── Hapus dept/divisi/jabatan (POST biar URL bersih) ──
if(isset($_POST['hapus_departemen'])){
  $id=$conn->real_escape_string($_POST['hapus_departemen']);
  $r=mysqli_fetch_assoc(mysqli_query($conn,"SELECT nama FROM departemen WHERE id='$id'"));
  mysqli_query($conn,"DELETE FROM departemen WHERE id='$id'");
  $kelola_popup = ['type'=>'hapus','kat'=>'Departemen','nama'=>$r['nama']??''];
}
if(isset($_POST['hapus_divisi'])){
  $id=$conn->real_escape_string($_POST['hapus_divisi']);
  $r=mysqli_fetch_assoc(mysqli_query($conn,"SELECT nama FROM divisi WHERE id='$id'"));
  mysqli_query($conn,"DELETE FROM divisi WHERE id='$id'");
  $kelola_popup = ['type'=>'hapus','kat'=>'Divisi','nama'=>$r['nama']??''];
}
if(isset($_POST['hapus_jabatan'])){
  $id=$conn->real_escape_string($_POST['hapus_jabatan']);
  $r=mysqli_fetch_assoc(mysqli_query($conn,"SELECT nama FROM jabatan WHERE id='$id'"));
  mysqli_query($conn,"DELETE FROM jabatan WHERE id='$id'");
  $kelola_popup = ['type'=>'hapus','kat'=>'Jabatan','nama'=>$r['nama']??''];
}

// ── Hapus user ──
if(isset($_GET['hapus'])) {
  $id=$conn->real_escape_string($_GET['hapus']);
  $hapus_user=mysqli_fetch_assoc(mysqli_query($conn,"SELECT username FROM users WHERE id='$id'"));
  mysqli_query($conn,"DELETE FROM users WHERE id='$id'");
  $popup_type='hapus'; $popup_username=$hapus_user['username']??'';
}

$users=$conn->query("SELECT * FROM users ORDER BY id ASC");
$edit_user=null;
if(isset($_GET['edit_id'])){
  $eid=$conn->real_escape_string($_GET['edit_id']);
  $edit_user=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE id='$eid'"));
}
$uid=$_SESSION['user_id']??0;
$unread=$uid?mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n']:0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    /* ── overrides khusus manage_users ── */
    .popup-overlay.popup-hidden { display:none !important; }

    .badge-unread {
      display:inline-flex; align-items:center; justify-content:center;
      background:#ef4444; color:#fff; border-radius:99px;
      font-size:0.6rem; font-weight:800;
      min-width:16px; height:16px; padding:0 4px; margin-left:4px;
    }

    /* Layout utama 3 kolom: form | tabel | kelola */
    .manage-grid {
      display: grid;
      grid-template-columns: 340px 1fr 300px;
      gap: 20px;
      align-items: start;
    }

    /* Kolom kiri: hanya form user */
    .left-col {
      display: flex;
      flex-direction: column;
      gap: 20px;
      position: sticky;
      top: 80px;
    }

    /* Kolom kanan: kelola */
    .right-kelola {
      position: sticky;
      top: 80px;
    }

    /* Kelola dept/divisi/jabatan card */
    .kelola-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 24px;
      animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1);
    }

    .kelola-card-title {
      font-family: 'Trebuchet MS','Segoe UI',sans-serif;
      font-size: 0.82rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      color: var(--muted);
      margin-bottom: 16px;
    }

    /* 1 kolom di dalam kelola card (kolom kanan sudah sempit) */
    .kelola-cols {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .kelola-col-title {
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--muted);
      margin-bottom: 8px;
    }

    /* Form tambah inline di kelola */
    .kelola-add-row {
      display: flex;
      gap: 6px;
      margin-bottom: 10px;
    }

    .kelola-add-row input {
      flex: 1;
      background: rgba(255,255,255,0.06);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px;
      color: var(--text);
      font-size: 0.8rem;
      padding: 7px 10px;
      outline: none;
      transition: border-color 0.2s;
      font-family: 'Segoe UI',Tahoma,Geneva,sans-serif;
    }

    .kelola-add-row input:focus { border-color: var(--accent); }
    .kelola-add-row input::placeholder { color: rgba(255,255,255,0.2); }

    .btn-kelola-add {
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 1rem;
      font-weight: 700;
      padding: 0 11px;
      cursor: pointer;
      line-height: 1;
      transition: opacity 0.2s;
      flex-shrink: 0;
    }

    .btn-kelola-add:hover { opacity: 0.82; }

    /* Baris item dept/divisi/jabatan */
    .kelola-item {
      display: flex;
      align-items: center;
      gap: 5px;
      margin-bottom: 6px;
    }

    .kelola-item-form {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
    }

    .kelola-item input {
      flex: 1;
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 7px;
      color: var(--text);
      font-size: 0.78rem;
      padding: 6px 9px;
      outline: none;
      transition: border-color 0.2s;
      font-family: 'Segoe UI',Tahoma,Geneva,sans-serif;
      min-width: 0;
    }

    .kelola-item input:focus { border-color: var(--accent); }

    .btn-kelola-edit {
      background: rgba(158,134,168,0.15);
      border: 1px solid rgba(158,134,168,0.25);
      border-radius: 6px;
      color: var(--accent);
      font-size: 0.68rem;
      font-weight: 700;
      padding: 5px 8px;
      cursor: pointer;
      white-space: nowrap;
      transition: background 0.2s;
      font-family: 'Segoe UI',Tahoma,Geneva,sans-serif;
      flex-shrink: 0;
    }

    .btn-kelola-edit:hover { background: rgba(158,134,168,0.28); }

    .btn-kelola-hapus {
      background: rgba(239,68,68,0.08);
      border: 1px solid rgba(239,68,68,0.2);
      border-radius: 6px;
      color: var(--danger);
      font-size: 0.68rem;
      font-weight: 700;
      padding: 5px 8px;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      transition: background 0.2s;
      flex-shrink: 0;
    }

    .btn-kelola-hapus:hover { background: rgba(239,68,68,0.2); }

    /* form-card override: hapus max-width biar pas di kolom kiri */
    .form-card { max-width: 100%; }

    /* Tabel kolom kanan */
    .right-col { min-width: 0; }
  </style>
</head>
<body>

  <!-- ══ POPUP SUKSES TAMBAH/EDIT USER ══ -->
  <?php if(isset($popup_type)&&($popup_type==='tambah'||$popup_type==='edit')): ?>
  <div class="popup-overlay" id="popupSukses">
    <div class="popup-box" id="popupSuksesBox">
      <div class="popup-icon">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
          <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
        </svg>
      </div>
      <div class="popup-title"><?= $popup_type==='tambah'?'User Ditambahkan!':'User Diperbarui!' ?></div>
      <div class="popup-msg">User <strong style="color:var(--accent2)"><?= htmlspecialchars($popup_username) ?></strong> berhasil <?= $popup_type==='tambah'?'ditambahkan ke sistem.':'diperbarui.' ?></div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-primary" onclick="tutupPopup('popupSukses','popupSuksesBox')">Oke, Lanjut</button>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- ══ POPUP HAPUS DONE USER ══ -->
  <?php if(isset($popup_type)&&$popup_type==='hapus'): ?>
  <div class="popup-overlay" id="popupHapusDone">
    <div class="popup-box" id="popupHapusDoneBox">
      <div class="popup-icon" style="background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="stroke:#ef4444;">
          <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
        </svg>
      </div>
      <div class="popup-title">User Dihapus!</div>
      <div class="popup-msg">User <strong style="color:#ef4444"><?= htmlspecialchars($popup_username) ?></strong> sudah dihapus dari sistem.</div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-primary" onclick="tutupPopup('popupHapusDone','popupHapusDoneBox')">Oke</button>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- ══ POPUP KONFIRMASI HAPUS USER ══ -->
  <div class="popup-overlay popup-hidden" id="popupKonfirmHapus">
    <div class="popup-box" id="popupKonfirmHapusBox">
      <div class="popup-icon" style="background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="stroke:#ef4444;">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
        </svg>
      </div>
      <div class="popup-title">Hapus User?</div>
      <div class="popup-msg">
        Yakin mau hapus user <strong style="color:#ef4444" id="namaUserHapus"></strong>?<br>
        Aksi ini <strong>tidak bisa dibatalin</strong>.
      </div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-secondary" onclick="tutupKonfirm()">Batal</button>
        <a href="#" id="btnKonfirmHapus" class="popup-btn" style="background:rgba(239,68,68,0.85);color:#fff;text-decoration:none;">Ya, Hapus</a>
      </div>
    </div>
  </div>

  <!-- ══ POPUP KONFIRMASI HAPUS DEPT/DIVISI/JABATAN ══ -->
  <div class="popup-overlay popup-hidden" id="popupKonfirmKelola">
    <div class="popup-box" id="popupKonfirmKelolaBox">
      <div class="popup-icon" style="background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="stroke:#ef4444;">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
        </svg>
      </div>
      <div class="popup-title" id="kelolaKonfirmTitle">Hapus?</div>
      <div class="popup-msg">
        Yakin mau hapus <span id="kelolaKonfirmKat" style="color:var(--muted)"></span>
        <strong style="color:#ef4444" id="kelolaKonfirmNama"></strong>?<br>
        Aksi ini <strong>tidak bisa dibatalin</strong>.
      </div>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-secondary" onclick="tutupKonfirmKelola()">Batal</button>
        <form method="POST" id="formHapusKelola" style="display:inline">
          <input type="hidden" id="hapusKelolaField" name="" value="">
          <button type="submit" class="popup-btn" style="background:rgba(239,68,68,0.85);color:#fff;border:none;cursor:pointer;">Ya, Hapus</button>
        </form>
      </div>
    </div>
  </div>

  <!-- ══ POPUP SUKSES KELOLA (tambah/hapus dept/divisi/jabatan) ══ -->
  <?php if(isset($kelola_popup)): ?>
  <div class="popup-overlay" id="popupKelolaResult">
    <div class="popup-box" id="popupKelolaResultBox">
      <?php if($kelola_popup['type']==='tambah'): ?>
      <div class="popup-icon">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
          <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
        </svg>
      </div>
      <div class="popup-title"><?= htmlspecialchars($kelola_popup['kat']) ?> Ditambahkan!</div>
      <div class="popup-msg"><strong style="color:var(--accent2)"><?= htmlspecialchars($kelola_popup['nama']) ?></strong> berhasil ditambahkan.</div>
      <?php else: ?>
      <div class="popup-icon" style="background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="stroke:#ef4444;">
          <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
        </svg>
      </div>
      <div class="popup-title"><?= htmlspecialchars($kelola_popup['kat']) ?> Dihapus!</div>
      <div class="popup-msg"><strong style="color:#ef4444"><?= htmlspecialchars($kelola_popup['nama']) ?></strong> sudah dihapus.</div>
      <?php endif; ?>
      <div class="popup-actions">
        <button class="popup-btn popup-btn-primary" onclick="tutupPopup('popupKelolaResult','popupKelolaResultBox')">Oke</button>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- ══ SIDEBAR ══ -->
  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="dashboard.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9.75L12 3l9 6.75V21H3V9.75z"/></svg>
        Dashboard
      </a>
      <a href="tasks.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        Semua Task
      </a>
      <a href="../user/create_task.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Buat Task
      </a>
      <a href="manage_users.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a4 4 0 00-5-3.87M9 20H4v-2a4 4 0 015-3.87m6-4a4 4 0 11-8 0 4 4 0 018 0zm6 4a2 2 0 11-4 0 2 2 0 014 0zM5 16a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        Manage Users
      </a>
      <a href="chat.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat
        <?php if($unread>0): ?><span class="badge-unread"><?= $unread ?></span><?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>
        Logout
      </a>
    </div>
  </div>

  <!-- ══ MAIN ══ -->
  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">Manage Users</div>
      <div class="topbar-user"></div>
    </div>

    <div class="page-content">
      <div class="manage-grid">

        <!-- ══ KOLOM KIRI ══ -->
        <div class="left-col">

          <!-- Form Tambah / Edit User -->
          <div class="form-card">
            <div style="font-family:'Trebuchet MS',sans-serif;font-size:1rem;font-weight:700;margin-bottom:20px;color:var(--text);">
              <?= $edit_user ? 'Edit User' : 'Tambah User' ?>
            </div>
            <form method="POST">
              <?php if($edit_user): ?>
                <input type="hidden" name="id" value="<?= $edit_user['id'] ?>">
              <?php endif; ?>

              <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" value="<?= htmlspecialchars($edit_user['username']??'') ?>" required>
              </div>

              <div class="form-group">
                <label>Password
                  <?php if($edit_user): ?>
                    <span style="color:var(--muted);font-size:0.65rem;text-transform:none;letter-spacing:0;font-weight:400;">(kosongkan jika tidak diubah)</span>
                  <?php endif; ?>
                </label>
                <input type="password" name="password" <?= $edit_user?'':'required' ?> placeholder="••••••••">
              </div>

              <div class="form-group">
                <label>Role</label>
                <select name="role">
                  <option value="user"  <?= ($edit_user['role']??'user')==='user'  ?'selected':'' ?>>User</option>
                  <option value="admin" <?= ($edit_user['role']??'')==='admin'      ?'selected':'' ?>>Admin</option>
                </select>
              </div>

              <div class="form-group">
                <label>Departemen</label>
                <select name="departemen">
                  <?php $d=mysqli_query($conn,"SELECT * FROM departemen"); while($row=mysqli_fetch_assoc($d)): ?>
                  <option value="<?= htmlspecialchars($row['nama']) ?>" <?= ($edit_user['departemen']??'')===$row['nama']?'selected':'' ?>>
                    <?= htmlspecialchars($row['nama']) ?>
                  </option>
                  <?php endwhile; ?>
                </select>
              </div>

              <div class="form-group">
                <label>Divisi</label>
                <select name="divisi">
                  <?php $d=mysqli_query($conn,"SELECT * FROM divisi"); while($row=mysqli_fetch_assoc($d)): ?>
                  <option value="<?= htmlspecialchars($row['nama']) ?>" <?= ($edit_user['divisi']??'')===$row['nama']?'selected':'' ?>>
                    <?= htmlspecialchars($row['nama']) ?>
                  </option>
                  <?php endwhile; ?>
                </select>
              </div>

              <div class="form-group">
                <label>Jabatan</label>
                <select name="jabatan">
                  <?php $d=mysqli_query($conn,"SELECT * FROM jabatan"); while($row=mysqli_fetch_assoc($d)): ?>
                  <option value="<?= htmlspecialchars($row['nama']) ?>" <?= ($edit_user['jabatan']??'')===$row['nama']?'selected':'' ?>>
                    <?= htmlspecialchars($row['nama']) ?>
                  </option>
                  <?php endwhile; ?>
                </select>
              </div>

              <div style="display:flex;gap:10px;">
                <button class="btn-save" name="<?= $edit_user?'edit':'tambah' ?>" type="submit">
                  <?= $edit_user ? 'Simpan Perubahan' : 'Tambah User' ?>
                </button>
                <?php if($edit_user): ?>
                  <a href="manage_users.php" class="btn-save" style="background:rgba(255,255,255,0.06);box-shadow:none;">Batal</a>
                <?php endif; ?>
              </div>
            </form>
          </div>

        </div><!-- end left-col -->

        <!-- ══ KOLOM TENGAH — TABEL USER ══ -->
        <div class="right-col">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Role</th>
                  <th>Departemen</th>
                  <th>Divisi</th>
                  <th>Jabatan</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php while($u=mysqli_fetch_assoc($users)): ?>
                <tr>
                  <td><?= htmlspecialchars($u['username']) ?></td>
                  <td>
                    <span class="badge <?= $u['role']==='admin'?'badge-process':'badge-open' ?>">
                      <?= htmlspecialchars($u['role']) ?>
                    </span>
                  </td>
                  <td><?= htmlspecialchars($u['departemen']??'-') ?></td>
                  <td><?= htmlspecialchars($u['divisi']??'-') ?></td>
                  <td><?= htmlspecialchars($u['jabatan']??'-') ?></td>
                  <td>
                    <div style="display:flex;gap:6px;">
                      <a href="manage_users.php?edit_id=<?= $u['id'] ?>" class="btn-edit">Edit</a>
                      <a href="#" class="btn-hapus" onclick="konfirmHapus(<?= $u['id'] ?>,'<?= addslashes($u['username']) ?>');return false;">Hapus</a>
                    </div>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div><!-- end kolom tengah -->

        <!-- ══ KOLOM KANAN — KELOLA DEPT ══ -->
        <div class="right-kelola">
          <div class="kelola-card">
            <div class="kelola-card-title">Kelola Departemen, Divisi & Jabatan</div>
            <div class="kelola-cols">

              <!-- DEPARTEMEN -->
              <div>
                <div class="kelola-col-title">Departemen</div>
                <form method="POST" class="kelola-add-row">
                  <input type="text" name="nama_departemen" placeholder="Tambah baru..." required>
                  <button name="tambah_departemen" class="btn-kelola-add" type="submit">+</button>
                </form>
                <?php $d=mysqli_query($conn,"SELECT * FROM departemen"); while($row=mysqli_fetch_assoc($d)): ?>
                <div class="kelola-item">
                  <form method="POST" class="kelola-item-form">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="nama_departemen" value="<?= htmlspecialchars($row['nama']) ?>">
                    <button name="edit_departemen" class="btn-kelola-edit" type="submit">Simpan</button>
                  </form>
                  <a href="#" class="btn-kelola-hapus"
                     onclick="konfirmHapusKelola('departemen',<?= $row['id'] ?>,'<?= addslashes($row['nama']) ?>','Departemen');return false;">✕</a>
                </div>
                <?php endwhile; ?>
              </div>

              <!-- DIVISI -->
              <div>
                <div class="kelola-col-title">Divisi</div>
                <form method="POST" class="kelola-add-row">
                  <input type="text" name="nama_divisi" placeholder="Tambah baru..." required>
                  <button name="tambah_divisi" class="btn-kelola-add" type="submit">+</button>
                </form>
                <?php $d=mysqli_query($conn,"SELECT * FROM divisi"); while($row=mysqli_fetch_assoc($d)): ?>
                <div class="kelola-item">
                  <form method="POST" class="kelola-item-form">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="nama_divisi" value="<?= htmlspecialchars($row['nama']) ?>">
                    <button name="edit_divisi" class="btn-kelola-edit" type="submit">Simpan</button>
                  </form>
                  <a href="#" class="btn-kelola-hapus"
                     onclick="konfirmHapusKelola('divisi',<?= $row['id'] ?>,'<?= addslashes($row['nama']) ?>','Divisi');return false;">✕</a>
                </div>
                <?php endwhile; ?>
              </div>

              <!-- JABATAN -->
              <div>
                <div class="kelola-col-title">Jabatan</div>
                <form method="POST" class="kelola-add-row">
                  <input type="text" name="nama_jabatan" placeholder="Tambah baru..." required>
                  <button name="tambah_jabatan" class="btn-kelola-add" type="submit">+</button>
                </form>
                <?php $d=mysqli_query($conn,"SELECT * FROM jabatan"); while($row=mysqli_fetch_assoc($d)): ?>
                <div class="kelola-item">
                  <form method="POST" class="kelola-item-form">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="nama_jabatan" value="<?= htmlspecialchars($row['nama']) ?>">
                    <button name="edit_jabatan" class="btn-kelola-edit" type="submit">Simpan</button>
                  </form>
                  <a href="#" class="btn-kelola-hapus"
                     onclick="konfirmHapusKelola('jabatan',<?= $row['id'] ?>,'<?= addslashes($row['nama']) ?>','Jabatan');return false;">✕</a>
                </div>
                <?php endwhile; ?>
              </div>

            </div>
          </div>
        </div><!-- end kolom kanan -->

      </div>
    </div>
    <!-- end page-content -->

  </div>
  <!-- end main-wrapper -->

  <script>
    // ── Utility tutup popup ──
    function tutupPopup(oid,bid){
      const o=document.getElementById(oid),b=document.getElementById(bid);
      b.classList.add('hide'); o.classList.add('hide');
      setTimeout(()=>o.classList.add('popup-hidden'),220);
    }

    // ── Konfirmasi hapus USER ──
    function konfirmHapus(id,username){
      document.getElementById('namaUserHapus').textContent=username;
      document.getElementById('btnKonfirmHapus').href='manage_users.php?hapus='+id;
      const o=document.getElementById('popupKonfirmHapus');
      o.classList.remove('popup-hidden','hide');
      document.getElementById('popupKonfirmHapusBox').classList.remove('hide');
    }
    function tutupKonfirm(){ tutupPopup('popupKonfirmHapus','popupKonfirmHapusBox'); }

    // ── Konfirmasi hapus DEPT/DIVISI/JABATAN ──
    function konfirmHapusKelola(tipe, id, nama, label){
      document.getElementById('kelolaKonfirmTitle').textContent = 'Hapus '+label+'?';
      document.getElementById('kelolaKonfirmKat').textContent   = label+' ';
      document.getElementById('kelolaKonfirmNama').textContent  = nama;
      // set form POST field
      var field = document.getElementById('hapusKelolaField');
      field.name  = 'hapus_'+tipe;
      field.value = id;
      const o=document.getElementById('popupKonfirmKelola');
      o.classList.remove('popup-hidden','hide');
      document.getElementById('popupKonfirmKelolaBox').classList.remove('hide');
    }
    function tutupKonfirmKelola(){ tutupPopup('popupKonfirmKelola','popupKonfirmKelolaBox'); }

    // ── Close on overlay click ──
    document.getElementById('popupKonfirmHapus').addEventListener('click',function(e){
      if(e.target===this) tutupKonfirm();
    });
    document.getElementById('popupKonfirmKelola').addEventListener('click',function(e){
      if(e.target===this) tutupKonfirmKelola();
    });

    <?php if(isset($popup_type)&&($popup_type==='tambah'||$popup_type==='edit')): ?>
    document.getElementById('popupSukses').addEventListener('click',function(e){
      if(e.target===this) tutupPopup('popupSukses','popupSuksesBox');
    });
    <?php endif; ?>
    <?php if(isset($popup_type)&&$popup_type==='hapus'): ?>
    document.getElementById('popupHapusDone').addEventListener('click',function(e){
      if(e.target===this) tutupPopup('popupHapusDone','popupHapusDoneBox');
    });
    <?php endif; ?>
    <?php if(isset($kelola_popup)): ?>
    document.getElementById('popupKelolaResult').addEventListener('click',function(e){
      if(e.target===this) tutupPopup('popupKelolaResult','popupKelolaResultBox');
    });
    <?php endif; ?>
  </script>
</body>
</html>