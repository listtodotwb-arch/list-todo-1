<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin'){
  header("Location: ../auth/login.php"); exit;
}

// Handle update status dari modal (AJAX)
if(isset($_POST['update_status_modal'])){
  $sid    = mysqli_real_escape_string($conn, $_POST['task_id']);
  $status = mysqli_real_escape_string($conn, $_POST['status']);
  mysqli_query($conn, "UPDATE tasks SET status='$status' WHERE id='$sid'");
  header('Content-Type: application/json');
  echo json_encode(['ok'=>true]); exit;
}

$total_open    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE status='Open'"))['t'];
$total_pending = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE status='Pending'"))['t'];
$total_process = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE status='Process'"))['t'];
$total_terlambat = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE status != 'Closed' AND target_tanggal IS NOT NULL AND target_tanggal < CURDATE()"))['t'];
$total_closed  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE status='Closed'"))['t'];
$total_all     = $total_open + $total_pending + $total_process + $total_closed;
$recent        = mysqli_query($conn,"SELECT * FROM tasks ORDER BY created_at DESC LIMIT 5");
$urg_high      = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE urgency='High'"))['t'];
$urg_medium    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE urgency='Medium'"))['t'];
$urg_low       = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM tasks WHERE urgency='Low'"))['t'];
$total_users   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM users WHERE role='user'"))['t'];
$top_users     = mysqli_query($conn,"SELECT nama, COUNT(*) as total FROM tasks WHERE status='Open' GROUP BY nama ORDER BY total DESC LIMIT 5");
$uid           = $_SESSION['user_id'] ?? 0;
$unread        = $uid ? mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n'] : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .db-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:24px;}
    .db-section{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;}
    .db-section-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
    .db-section-header h4{font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:var(--muted);}
    .db-section-header a{font-size:0.75rem;color:var(--accent2);text-decoration:none;font-weight:600;}
    .db-section-header a:hover{text-decoration:underline;}
    .recent-row{display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid rgba(34,34,48,0.5);transition:background 0.15s;}
    .recent-row:last-child{border-bottom:none;}
    .recent-row:hover{background:rgba(158,134,168,0.05);}
    .recent-tid{font-size:0.72rem;font-weight:700;color:var(--accent2);min-width:64px;}
    .recent-info{flex:1;min-width:0;}
    .recent-name{font-size:0.82rem;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .recent-todo{font-size:0.74rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;}
    .recent-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;}
    .urg-list{padding:18px 20px;display:flex;flex-direction:column;gap:14px;}
    .urg-label-row{display:flex;justify-content:space-between;margin-bottom:6px;font-size:0.78rem;font-weight:600;}
    .urg-label-row span:first-child{color:var(--text);}
    .urg-label-row span:last-child{color:var(--muted);}
    .urg-bar-bg{width:100%;height:7px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;}
    .urg-bar-fill{height:100%;border-radius:99px;transition:width 0.6s cubic-bezier(0.16,1,0.3,1);}
    .urg-bar-fill.high{background:#ef4444;}
    .urg-bar-fill.medium{background:#f59e0b;}
    .urg-bar-fill.low{background:#22c55e;}
    .summary-card{background:linear-gradient(135deg,var(--accent) 0%,var(--accent2) 100%);border-radius:14px;padding:22px 24px;display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;position:relative;overflow:hidden;}
    .summary-card::before{content:'';position:absolute;top:-40px;right:-40px;width:140px;height:140px;background:rgba(255,255,255,0.08);border-radius:50%;}
    .summary-card .sc-left h3{font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:rgba(255,255,255,0.7);margin-bottom:6px;}
    .summary-card .sc-left p{font-family:'Syne',sans-serif;font-size:2.2rem;font-weight:800;color:#fff;line-height:1;}
    .summary-card .sc-left span{font-size:0.78rem;color:rgba(255,255,255,0.65);margin-top:4px;display:block;}
    .summary-card .sc-right{text-align:right;position:relative;z-index:1;}
    .summary-card .sc-right .sc-stat{font-size:0.75rem;color:rgba(255,255,255,0.7);margin-bottom:3px;}
    .summary-card .sc-right .sc-stat strong{color:#fff;font-weight:700;}
    .topuser-row{display:flex;align-items:center;gap:12px;padding:11px 20px;border-bottom:1px solid rgba(34,34,48,0.5);}
    .topuser-row:last-child{border-bottom:none;}
    .topuser-rank{width:22px;height:22px;border-radius:50%;background:rgba(158,134,168,0.15);display:flex;align-items:center;justify-content:center;font-size:0.65rem;font-weight:800;color:var(--accent);flex-shrink:0;}
    .topuser-rank.gold{background:rgba(245,158,11,0.15);color:#f59e0b;}
    .topuser-rank.silver{background:rgba(156,163,175,0.15);color:#9ca3af;}
    .topuser-rank.bronze{background:rgba(180,120,60,0.15);color:#b47c3c;}
    .topuser-name{flex:1;font-size:0.84rem;font-weight:600;color:var(--text);}
    .topuser-count{font-size:0.78rem;font-weight:700;color:var(--open);background:rgba(59,130,246,0.1);padding:3px 10px;border-radius:99px;}
    .badge-unread{display:inline-flex;align-items:center;justify-content:center;background:#ef4444;color:#fff;border-radius:99px;font-size:0.6rem;font-weight:800;min-width:16px;height:16px;padding:0 4px;margin-left:4px;}
    @media(max-width:900px){.db-grid{grid-template-columns:1fr;}}
    .dashboard .card{cursor:pointer;transition:transform 0.15s,box-shadow 0.15s;}
    .dashboard .card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,0.3);}

    /* Modal */
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:9000;align-items:center;justify-content:center;}
    .modal-overlay.show{display:flex;}
    .modal-box{background:#1a1a22;border:1px solid rgba(255,255,255,0.08);border-radius:16px;width:min(1100px,97vw);max-height:88vh;display:flex;flex-direction:column;overflow:hidden;animation:modalIn 0.2s ease;}
    @keyframes modalIn{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
    .modal-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0;}
    .modal-header h3{font-size:0.9rem;font-weight:700;color:#eeeef5;}
    .modal-close{background:none;border:none;color:#777;cursor:pointer;font-size:1.2rem;line-height:1;padding:4px;}
    .modal-close:hover{color:#eeeef5;}
    .modal-body{overflow-y:auto;flex:1;}
    .modal-empty{padding:32px 20px;text-align:center;color:#555;font-size:0.85rem;}
    .modal-loading{padding:32px 20px;text-align:center;color:#555;font-size:0.85rem;}
    .modal-badge-title{display:inline-block;padding:3px 10px;border-radius:6px;font-size:0.72rem;font-weight:700;}
    .modal-badge-title.open{background:rgba(59,130,246,0.15);color:#3b82f6;}
    .modal-badge-title.pending{background:rgba(245,158,11,0.15);color:#f59e0b;}
    .modal-badge-title.process{background:rgba(158,134,168,0.15);color:#9E86A8;}
    .modal-badge-title.closed{background:rgba(34,197,94,0.15);color:#22c55e;}
    .modal-count{font-size:0.72rem;color:#555;padding:10px 20px;border-bottom:1px solid rgba(255,255,255,0.05);flex-shrink:0;}

    /* Tabel modal */
    .modal-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;}
    .modal-table{width:100%;border-collapse:collapse;font-size:0.8rem;}
    .modal-table thead tr{border-bottom:1px solid rgba(255,255,255,0.07);}
    .modal-table thead th{padding:10px 12px;text-align:left;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#555;white-space:nowrap;}
    .modal-table tbody tr{border-bottom:1px solid rgba(255,255,255,0.04);transition:background 0.12s;}
    .modal-table tbody tr:last-child{border-bottom:none;}
    .modal-table tbody tr:hover{background:rgba(255,255,255,0.03);}
    .modal-table td{padding:10px 12px;color:#ccc;vertical-align:middle;white-space:nowrap;}
    .modal-table td:nth-child(4){max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}

    /* Kolom Aksi sticky di kanan — ga akan kepotong lagi */
    .modal-table td:last-child,
    .modal-table th:last-child{position:sticky;right:0;background:#1a1a22;z-index:2;box-shadow:-2px 0 6px rgba(0,0,0,0.4);}
    .modal-table tbody tr:hover td:last-child{background:#1e1e28;}

    .modal-status-form{display:inline-flex;align-items:center;gap:5px;}
    .modal-status-select{background:#1a1a22;border:1px solid rgba(255,255,255,0.1);border-radius:6px;color:#eeeef5;font-size:0.72rem;padding:3px 7px;cursor:pointer;outline:none;appearance:none;-webkit-appearance:none;}
    .modal-status-select:focus{border-color:rgba(159,187,60,0.5);}
    .modal-status-select option{background:#1a1a22;color:#eeeef5;}
    .modal-btn-ok{background:rgba(159,187,60,0.15);color:#9FBB3C;border:none;border-radius:6px;padding:3px 9px;font-size:0.7rem;font-weight:600;cursor:pointer;transition:background 0.15s;}
    .modal-btn-ok:hover{background:rgba(159,187,60,0.3);}
    .modal-btn-edit{display:inline-flex;align-items:center;gap:5px;background:rgba(158,134,168,0.12);color:#9E86A8;border:1px solid rgba(158,134,168,0.2);border-radius:6px;padding:4px 10px;font-size:0.72rem;font-weight:600;text-decoration:none;transition:background 0.15s;}
    .modal-btn-edit:hover{background:rgba(158,134,168,0.25);}
    .swkt-late{color:#ef4444;font-weight:700;}
    .swkt-ok{color:#22c55e;}
    .modal-toast{display:none;position:fixed;bottom:24px;right:24px;background:rgba(34,197,94,0.15);border:1px solid rgba(34,197,94,0.3);color:#22c55e;padding:10px 18px;border-radius:8px;font-size:0.83rem;font-weight:500;z-index:99999;}
    @keyframes fadeInUp{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}
  </style>
</head>
<body>
  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="dashboard.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9.75L12 3l9 6.75V21H3V9.75z"/></svg>Dashboard
      </a>
      <a href="tasks.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>Semua Task
      </a>
      <a href="../user/create_task.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>Buat Task
      </a>
      <a href="manage_users.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a4 4 0 00-5-3.87M9 20H4v-2a4 4 0 015-3.87m6-4a4 4 0 11-8 0 4 4 0 018 0zm6 4a2 2 0 11-4 0 2 2 0 014 0zM5 16a2 2 0 11-4 0 2 2 0 014 0z"/></svg>Manage Users
      </a>
      <a href="chat.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat<?php if($unread>0): ?><span class="badge-unread"><?= $unread ?></span><?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>Logout
      </a>
    </div>
  </div>

  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">Dashboard</div>
      <div class="topbar-user">
        <div class="avatar"><?= strtoupper(substr($_SESSION['username'],0,1)) ?></div>
        <?= htmlspecialchars($_SESSION['username']) ?>
      </div>
    </div>
    <div class="page-content">
      <div class="summary-card">
        <div class="sc-left">
          <h3>Total Task</h3>
          <p><?= $total_all ?></p>
          <span><?= $total_users ?> user aktif terdaftar</span>
        </div>
        <div class="sc-right">
          <div class="sc-stat">Open &nbsp;<strong><?= $total_open ?></strong></div>
          <div class="sc-stat">Pending &nbsp;<strong><?= $total_pending ?></strong></div>
         <div class="sc-stat">Terlambat &nbsp;<strong><?= $total_terlambat ?></strong></div>
          <div class="sc-stat">Done &nbsp;<strong><?= $total_closed ?></strong></div>
        </div>
      </div>

     <div class="dashboard">
  <a href="tasks.php?status=Open"    class="card open"    style="text-decoration:none;display:block;"><h3>Open</h3><p><?= $total_open ?></p></a>
  <a href="tasks.php?status=Pending" class="card pending" style="text-decoration:none;display:block;"><h3>Pending</h3><p><?= $total_pending ?></p></a>
  <a href="tasks.php?waktu=terlambat" class="card process" style="text-decoration:none;display:block;"><h3>Late</h3><p style="color:#ef4444;"><?= $total_terlambat ?></p><small style="font-size:0.7rem;color:#ef4444;"></small></a>
  <a href="tasks.php?status=Closed"  class="card closed"  style="text-decoration:none;display:block;"><h3>Done</h3><p><?= $total_closed ?></p></a>
</div>

      <div class="db-grid">
        <div class="db-section">
          <div class="db-section-header"><h4>Task Terbaru</h4><a href="tasks.php">Lihat semua &rarr;</a></div>
          <?php while($r=mysqli_fetch_assoc($recent)): ?>
          <div class="recent-row">
            <div class="recent-tid"><?= htmlspecialchars($r['task_id']??$r['id']) ?></div>
            <div class="recent-info">
              <div class="recent-name"><?= htmlspecialchars($r['nama']) ?></div>
              <div class="recent-todo"><?= htmlspecialchars($r['todo']) ?></div>
            </div>
            <div class="recent-meta">
              <span class="badge badge-<?= strtolower($r['status']) ?>"><?= $r['status'] ?></span>
              <?php $u=$r['urgency'];$uc=strtolower($u)==='high'?'#ef4444':(strtolower($u)==='medium'?'#f59e0b':'#22c55e'); ?>
              <span class="urgency-badge" style="color:<?= $uc ?>;font-size:0.68rem;"><?= $u ?></span>
            </div>
          </div>
          <?php endwhile; ?>
        </div>

        <div class="db-section">
          <div class="db-section-header"><h4>Urgency Breakdown</h4></div>
          <div class="urg-list">
            <?php
              $urg_total=max($urg_high+$urg_medium+$urg_low,1);
              foreach([['High',$urg_high,'high'],['Medium',$urg_medium,'medium'],['Low',$urg_low,'low']] as [$label,$val,$cls]):
                $pct=round($val/$urg_total*100);
            ?>
            <div class="urg-row">
              <div class="urg-label-row"><span><?= $label ?></span><span><?= $val ?> task &nbsp;(<?= $pct ?>%)</span></div>
              <div class="urg-bar-bg"><div class="urg-bar-fill <?= $cls ?>" style="width:<?= $pct ?>%"></div></div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="db-section-header" style="margin-top:8px;"><h4>Top User — Task Open</h4></div>
          <?php $rank=1; while($u=mysqli_fetch_assoc($top_users)): $rc=$rank===1?'gold':($rank===2?'silver':($rank===3?'bronze':'')); ?>
          <div class="topuser-row">
            <div class="topuser-rank <?= $rc ?>"><?= $rank ?></div>
            <div class="topuser-name"><?= htmlspecialchars($u['nama']) ?></div>
            <div class="topuser-count"><?= $u['total'] ?></div>
          </div>
          <?php $rank++; endwhile; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- MODAL -->
  <div class="modal-overlay" id="taskModal" onclick="closeModalOutside(event)">
    <div class="modal-box">
      <div class="modal-header">
        <h3 id="modalTitle">Task</h3>
        <button class="modal-close" onclick="closeModal()">&times;</button>
      </div>
      <div id="modalCount" class="modal-count" style="display:none;"></div>
      <div class="modal-body" id="modalBody">
        <div class="modal-loading">Memuat...</div>
      </div>
    </div>
  </div>

  <div class="modal-toast" id="modalToast"></div>

  <script>
const urgColor = { High:'#ef4444', Medium:'#f59e0b', Low:'#22c55e' };
const hariMap  = {0:'Min',1:'Sen',2:'Sel',3:'Rab',4:'Kam',5:'Jum',6:'Sab'};
const bulanMap = {0:'Jan',1:'Feb',2:'Mar',3:'Apr',4:'Mei',5:'Jun',6:'Jul',7:'Agu',8:'Sep',9:'Okt',10:'Nov',11:'Des'};

function escHtml(s){ const d=document.createElement('div');d.textContent=s;return d.innerHTML; }

function formatTgl(str) {
  if (!str) return '-';
  const d = new Date(str);
  return hariMap[d.getDay()] + ', ' +
         String(d.getDate()).padStart(2,'0') + ' ' +
         bulanMap[d.getMonth()] + ' ' + d.getFullYear() + ' ' +
         String(d.getHours()).padStart(2,'0') + ':' +
         String(d.getMinutes()).padStart(2,'0');
}

let currentModalStatus = '';

function openModal(status) {
  currentModalStatus = status;
  const modal = document.getElementById('taskModal');
  const title = document.getElementById('modalTitle');
  const body  = document.getElementById('modalBody');
  const count = document.getElementById('modalCount');

  title.innerHTML = `Task — <span class="modal-badge-title ${status.toLowerCase()}">${status}</span>`;
  body.innerHTML  = '<div class="modal-loading">Memuat data...</div>';
  count.style.display = 'none';
  modal.classList.add('show');

  fetch(`../api/get_tasks_by_status.php?status=${encodeURIComponent(status)}`)
    .then(r => r.json())
    .then(tasks => {
      if (!Array.isArray(tasks) || tasks.length === 0) {
        body.innerHTML = `<div class="modal-empty">Tidak ada task dengan status <strong>${status}</strong>.</div>`;
        return;
      }

      count.textContent = tasks.length + ' task ditemukan';
      count.style.display = 'block';

      const today = new Date().toISOString().split('T')[0];

      const rows = tasks.map(t => {
        const uc     = urgColor[t.urgency] || '#aaa';
        const isLate = t.status !== 'Closed' && t.target_tanggal && t.target_tanggal < today;
        const swkt   = isLate
          ? `<span class="swkt-late">⚠️ Terlambat</span>`
          : `<span class="swkt-ok">On Time</span>`;

        const statusOptions = ['Open','Pending','Process','Closed'].map(s =>
          `<option value="${s}" ${t.status===s?'selected':''}>${s}</option>`
        ).join('');

        return `<tr>
          <td>${escHtml(String(t.id))}</td>
          <td>${escHtml(t.nama||'-')}</td>
          <td><span style="color:${uc};font-weight:700;">${escHtml(t.urgency||'-')}</span></td>
          <td title="${escHtml(t.todo||'')}">${escHtml(t.todo||'-')}</td>
          <td>${escHtml(t.departemen||'-')}</td>
          <td>${escHtml(t.DIVISI||t.divisi||'-')}</td>
          <td>${escHtml(t.keterangan||'-')}</td>
          <td>${formatTgl(t.created_at)}</td>
          <td>${escHtml(t.target_tanggal||'-')}</td>
          <td>${swkt}</td>
          <td>
            <form class="modal-status-form" onsubmit="updateStatus(event,${t.id})">
              <select name="status" class="modal-status-select">${statusOptions}</select>
              <button type="submit" class="modal-btn-ok">OK</button>
            </form>
          </td>
          <td>
            <a href="edit_task.php?id=${t.id}" class="modal-btn-edit">
              ✏️ Edit
            </a>
          </td>
        </tr>`;
      }).join('');

      body.innerHTML = `
        <div class="modal-table-wrap">
          <table class="modal-table">
            <thead><tr>
              <th>ID</th><th>Nama</th><th>Urgency</th><th>Task</th>
              <th>Departemen</th><th>Divisi</th><th>Keterangan</th>
              <th>Dibuat</th><th>Target</th><th>Status Waktu</th>
              <th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    })
    .catch(() => {
      body.innerHTML = '<div class="modal-empty">Gagal memuat data. Coba lagi.</div>';
    });
}

function updateStatus(e, taskId) {
  e.preventDefault();
  const form   = e.target;
  const status = form.querySelector('select').value;

  fetch('dashboard.php', {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: `update_status_modal=1&task_id=${taskId}&status=${encodeURIComponent(status)}`
  })
  .then(r => r.json())
  .then(res => {
    if (res.ok) {
      showModalToast('Status berhasil diupdate!');
      // Refresh isi modal setelah update
      setTimeout(() => openModal(currentModalStatus), 800);
    }
  })
  .catch(() => showModalToast('Gagal update status.'));
}

function showModalToast(msg) {
  const t = document.getElementById('modalToast');
  t.textContent = msg;
  t.style.display = 'block';
  t.style.animation = 'fadeInUp 0.25s ease';
  setTimeout(() => { t.style.display = 'none'; }, 2500);
}

function closeModal() {
  document.getElementById('taskModal').classList.remove('show');
}

function closeModalOutside(e) {
  if (e.target === document.getElementById('taskModal')) closeModal();
}

document.addEventListener('keydown', e => { if(e.key==='Escape') closeModal(); });
</script>
</body>
</html>