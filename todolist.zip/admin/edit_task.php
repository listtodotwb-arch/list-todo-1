<?php
session_start();
include "../config/db.php";

if(!isset($_GET['id'])) { header("Location: tasks.php"); exit; }

$id   = mysqli_real_escape_string($conn, $_GET['id']);
$task = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'"));
if(!$task) { header("Location: tasks.php"); exit; }

$isJson = isset($_GET['json']) && $_GET['json'] == '1';

// ===== HAPUS =====
if(isset($_GET['hapus']) && $_GET['hapus'] == $id) {
  mysqli_query($conn, "DELETE FROM tasks WHERE id='$id'");
  header("Location: tasks.php?deleted=1");
  exit;
}

// ===== TAMBAH TARGET (POST) =====
if(isset($_POST['tambah_target'])) {
  $target_baru = mysqli_real_escape_string($conn, $_POST['target_baru']);
  $assigned_to = mysqli_real_escape_string($conn, $_POST['assigned_to']);
  $catatan     = mysqli_real_escape_string($conn, $_POST['catatan'] ?? '');
  if($target_baru && $assigned_to) {
    mysqli_query($conn, "INSERT INTO task_targets (task_id, target_tanggal, assigned_to, catatan) VALUES ('$id','$target_baru','$assigned_to','$catatan')");
    mysqli_query($conn, "UPDATE tasks SET target_tanggal='$target_baru', status='Open' WHERE id='$id'");
    if($isJson) { echo json_encode(['success'=>true]); exit; }
    $success = "Target baru berhasil ditambahkan!";
    $task = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'"));
  } else {
    if($isJson) { echo json_encode(['success'=>false,'msg'=>'Field kosong']); exit; }
  }
}

// ===== UPDATE TASK (POST) =====
if(isset($_POST['update'])) {
  $nama    = mysqli_real_escape_string($conn, $_POST['nama']);
  $urgency = mysqli_real_escape_string($conn, $_POST['urgency']);
  $todo    = mysqli_real_escape_string($conn, $_POST['todo']);
  $dept    = mysqli_real_escape_string($conn, $_POST['departemen']);
  $divisi  = mysqli_real_escape_string($conn, $_POST['divisi']);
  $status  = mysqli_real_escape_string($conn, $_POST['status']);
  $ok = mysqli_query($conn, "UPDATE tasks SET nama='$nama', urgency='$urgency', todo='$todo', departemen='$dept', DIVISI='$divisi', status='$status' WHERE id='$id'");
  if($isJson) { echo json_encode(['success'=>(bool)$ok]); exit; }
  $success = "Task berhasil diupdate!";
  $task = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'"));
}

// ===== GET DATA (JSON untuk modal) =====
if($isJson && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $task = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'"));

  // Ambil riwayat target
  $extra_targets = mysqli_query($conn, "SELECT tt.*, u.username FROM task_targets tt LEFT JOIN users u ON tt.assigned_to=u.id WHERE tt.task_id='$id' ORDER BY tt.created_at DESC");
  $targets = [];
  while($t = mysqli_fetch_assoc($extra_targets)) {
    $t['created_at'] = date('d M Y H:i', strtotime($t['created_at']));
    $targets[] = $t;
  }

  echo json_encode([
    'id'            => $task['id'],
    'nama'          => $task['nama'],
    'urgency'       => $task['urgency'],
    'todo'          => $task['todo'],
    'departemen'    => $task['departemen'],
    'divisi'        => $task['DIVISI'] ?? $task['divisi'] ?? '',
    'status'        => $task['status'],
    'target_tanggal'=> $task['target_tanggal'],
    'targets'       => $targets,
  ]);
  exit;
}

// ===== FALLBACK: kalau diakses langsung (bukan via modal) redirect aja =====
header("Location: tasks.php");
exit;