<?php
session_start();
include "../config/db.php";

if(isset($_POST['update_status'])) {
  $sid    = mysqli_real_escape_string($conn, $_POST['task_id']);
  $status = mysqli_real_escape_string($conn, $_POST['status']);
  mysqli_query($conn, "UPDATE tasks SET status='$status' WHERE id='$sid'");
  header("Location: tasks.php?" . http_build_query(array_filter(['search'=>$_GET['search']??'','status'=>$_GET['status']??'','urgency'=>$_GET['urgency']??''])) . "&status_updated=1");
  exit;
}

$where = "WHERE 1=1";
if(!empty($_GET['search']))  $where .= " AND (nama LIKE '%".mysqli_real_escape_string($conn,$_GET['search'])."%' OR todo LIKE '%".mysqli_real_escape_string($conn,$_GET['search'])."%')";
if(!empty($_GET['status']))  $where .= " AND status = '".mysqli_real_escape_string($conn,$_GET['status'])."'";
if(!empty($_GET['urgency'])) $where .= " AND urgency = '".mysqli_real_escape_string($conn,$_GET['urgency'])."'";
if(!empty($_GET['waktu']) && $_GET['waktu'] === 'terlambat') {
    $where .= " AND status != 'Closed' AND target_tanggal IS NOT NULL AND target_tanggal < CURDATE()";
}

$data = mysqli_query($conn,"SELECT * FROM tasks $where ORDER BY created_at DESC");
$uid  = $_SESSION['user_id'] ?? 0;
$unread = $uid ? mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as n FROM chats WHERE to_id='$uid' AND is_read=0"))['n'] : 0;

// Ambil semua user untuk dropdown di modal
$all_users = mysqli_query($conn, "SELECT id, username FROM users ORDER BY username ASC");
$users_list = [];
while($u = mysqli_fetch_assoc($all_users)) $users_list[] = $u;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Semua Task — To Do List</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .status-form{display:inline-flex;align-items:center;gap:6px;}
    .status-select{
      background: #1a1a22 !important;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 6px;
      color: #eeeef5;
      font-size: 0.75rem;
      padding: 4px 8px;
      cursor: pointer;
      outline: none;
      appearance: none;
      -webkit-appearance: none;
    }
    .status-select:focus{border-color:rgba(159,187,60,0.5);}
    .status-select option {
      background: #1a1a22 !important;
      color: #eeeef5 !important;
    }
    .btn-status{background:rgba(159,187,60,0.15);color:#9FBB3C;border:none;border-radius:6px;padding:4px 10px;font-size:0.73rem;font-weight:600;cursor:pointer;transition:background 0.18s;}
    .btn-status:hover{background:rgba(159,187,60,0.3);}
    .badge-unread{display:inline-flex;align-items:center;justify-content:center;background:#ef4444;color:#fff;border-radius:99px;font-size:0.6rem;font-weight:800;min-width:16px;height:16px;padding:0 4px;margin-left:4px;}
    .toast{position:fixed;bottom:24px;right:24px;background:rgba(34,197,94,0.15);border:1px solid rgba(34,197,94,0.3);color:#22c55e;padding:10px 18px;border-radius:8px;font-size:0.83rem;font-weight:500;z-index:9999;animation:fadeInUp 0.25s ease;}
    .toast.red{background:rgba(239,68,68,0.15);border-color:rgba(239,68,68,0.3);color:#ef4444;}
    @keyframes fadeInUp{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}

    /* === MODAL === */
    .modal-overlay{
      display:none;
      position:fixed;inset:0;
      background:rgba(0,0,0,0.7);
      backdrop-filter:blur(4px);
      z-index:1000;
      align-items:center;
      justify-content:center;
      padding:20px;
    }
    .modal-overlay.active{display:flex;}
    .modal-box{
      background:#1a1a2e;
      border:1px solid rgba(255,255,255,0.08);
      border-radius:16px;
      width:100%;
      max-width:620px;
      max-height:90vh;
      overflow-y:auto;
      padding:28px;
      position:relative;
      animation:modalIn 0.25s ease;
    }
    @keyframes modalIn{from{opacity:0;transform:translateY(-16px);}to{opacity:1;transform:translateY(0);}}
    .modal-close{
      position:absolute;top:16px;right:16px;
      background:rgba(255,255,255,0.06);
      border:none;border-radius:8px;
      color:#aaa;font-size:1rem;
      width:32px;height:32px;
      cursor:pointer;display:flex;align-items:center;justify-content:center;
      transition:background 0.18s;
    }
    .modal-close:hover{background:rgba(239,68,68,0.2);color:#ef4444;}
    .modal-title{font-size:1rem;font-weight:700;color:#eeeef5;margin-bottom:20px;}
    .modal-section{margin-bottom:20px;}
    .modal-section-title{font-size:0.75rem;font-weight:700;color:#55556a;letter-spacing:0.08em;margin-bottom:12px;text-transform:uppercase;}
    .mform-group{margin-bottom:14px;}
    .mform-group label{display:block;font-size:0.78rem;color:#aaa;margin-bottom:5px;font-weight:500;}
    .mform-group input,
    .mform-group select,
    .mform-group textarea{
      width:100%;
      background:#12121c;
      border:1px solid rgba(255,255,255,0.08);
      border-radius:8px;
      color:#eeeef5;
      font-size:0.83rem;
      padding:9px 12px;
      outline:none;
      box-sizing:border-box;
      font-family:inherit;
      transition:border-color 0.18s;
    }
    .mform-group input:focus,
    .mform-group select:focus,
    .mform-group textarea:focus{border-color:rgba(159,187,60,0.5);}
    .mform-group textarea{resize:vertical;min-height:72px;}
    .mform-group select option{background:#12121c;}
    .mform-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    .btn-modal-save{
      background:rgba(159,187,60,0.15);
      color:#9FBB3C;
      border:1px solid rgba(159,187,60,0.3);
      border-radius:8px;
      padding:9px 20px;
      font-size:0.83rem;font-weight:700;
      cursor:pointer;
      transition:background 0.18s;
    }
    .btn-modal-save:hover{background:rgba(159,187,60,0.3);}
    .btn-modal-danger{
      background:rgba(239,68,68,0.1);
      color:#ef4444;
      border:1px solid rgba(239,68,68,0.3);
      border-radius:8px;
      padding:9px 20px;
      font-size:0.83rem;font-weight:700;
      cursor:pointer;
      transition:background 0.18s;
    }
    .btn-modal-danger:hover{background:rgba(239,68,68,0.25);}
    .modal-footer{display:flex;gap:10px;justify-content:flex-end;margin-top:20px;padding-top:16px;border-top:1px solid rgba(255,255,255,0.06);}
    .pending-section{
      background:rgba(245,158,11,0.05);
      border:1px solid rgba(245,158,11,0.2);
      border-radius:10px;
      padding:16px;
      margin-top:16px;
    }
    .pending-section-title{font-size:0.8rem;font-weight:700;color:#f59e0b;margin-bottom:12px;}
    .btn-add-target{
      background:rgba(245,158,11,0.15);
      color:#f59e0b;
      border:1px solid rgba(245,158,11,0.3);
      border-radius:8px;
      padding:8px 16px;
      font-size:0.8rem;font-weight:600;
      cursor:pointer;
      transition:background 0.18s;
    }
    .btn-add-target:hover{background:rgba(245,158,11,0.3);}
    .target-history-table{width:100%;font-size:0.78rem;border-collapse:collapse;margin-top:12px;}
    .target-history-table th{text-align:left;padding:5px 8px;color:#55556a;font-weight:600;}
    .target-history-table td{padding:5px 8px;border-top:1px solid rgba(255,255,255,0.05);}
    .modal-loading{display:flex;align-items:center;justify-content:center;height:120px;color:#55556a;font-size:0.85rem;}
    .spinner{width:20px;height:20px;border:2px solid rgba(159,187,60,0.2);border-top-color:#9FBB3C;border-radius:50%;animation:spin 0.7s linear infinite;margin-right:10px;}
    @keyframes spin{to{transform:rotate(360deg);}}
  </style>
</head>
<body>
  <?php if(isset($_GET['status_updated'])): ?><div class="toast" id="toast">Status berhasil diupdate!</div><?php endif; ?>
  <?php if(isset($_GET['deleted'])): ?><div class="toast red" id="toast">Task berhasil dihapus.</div><?php endif; ?>
  <div id="toastModal" class="toast" style="display:none;"></div>

  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-title">To Do List</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-label">Menu</div>
      <a href="dashboard.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9.75L12 3l9 6.75V21H3V9.75z"/></svg>Dashboard
      </a>
      <a href="tasks.php" class="nav-item active">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>Semua Task
      </a>
      <a href="../user/create_task.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>Buat Task
      </a>
      <a href="manage_users.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a4 4 0 00-5-3.87M9 20H4v-2a4 4 0 015-3.87m6-4a4 4 0 11-8 0 4 4 0 018 0zm6 4a2 2 0 11-4 0 2 2 0 014 0zM5 16a2 2 0 11-4 0 2 2 0 014 0z"/></svg>Manage Users
      </a>
      <a href="chat.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8a9.77 9.77 0 01-4-.83L3 20l1.09-3.27C3.4 15.56 3 13.82 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        Chat<?php if($unread>0): ?><span class="badge-unread"><?= $unread ?></span><?php endif; ?>
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="../auth/logout.php" class="nav-item">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h5a2 2 0 012 2v1"/></svg>Logout
      </a>
    </div>
  </div>

  <div class="main-wrapper">
    <div class="topbar">
      <div class="topbar-title">Semua Task</div>
      <div class="topbar-user"></div>
    </div>
    <div class="page-content">
      <form method="GET" class="filter-bar">
        <div class="filter-search-wrap">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#55556a" stroke-width="2" class="filter-search-icon"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/></svg>
          <input type="text" name="search" class="filter-input" placeholder="Cari nama / task..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        </div>
        <select name="status" class="filter-select">
          <option value="">Semua Status</option>
          <option value="Open"    <?= ($_GET['status']??'')==='Open'    ?'selected':'' ?>>Open</option>
          <option value="Pending" <?= ($_GET['status']??'')==='Pending' ?'selected':'' ?>>Pending</option>
          <option value="Process" <?= ($_GET['status']??'')==='Process' ?'selected':'' ?>>Process</option>
          <option value="Closed"  <?= ($_GET['status']??'')==='Closed'  ?'selected':'' ?>>Closed</option>
        </select>
        <select name="urgency" class="filter-select">
          <option value="">Semua Urgency</option>
          <option value="Low"    <?= ($_GET['urgency']??'')==='Low'    ?'selected':'' ?>>Low</option>
          <option value="Medium" <?= ($_GET['urgency']??'')==='Medium' ?'selected':'' ?>>Medium</option>
          <option value="High"   <?= ($_GET['urgency']??'')==='High'   ?'selected':'' ?>>High</option>
        </select>
        <button type="submit" class="btn filter-btn">Cari</button>
        <?php if(!empty($_GET['search'])||!empty($_GET['status'])||!empty($_GET['urgency'])): ?>
          <a href="tasks.php" class="filter-reset">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>Reset
          </a>
        <?php endif; ?>
      </form>

      <div class="table-wrap">
        <table>
          <thead>
           <tr><th>ID</th><th>Nama</th><th>Urgency</th><th>Task</th><th>Departemen</th><th>Divisi</th><th>Action</th><th>Status</th><th>Dibuat</th><th>Target</th>
<th>Status Waktu</th><th>Edit</th></tr>
          </thead>
          <tbody>
            <?php while($row = mysqli_fetch_assoc($data)): 
              $today = date('Y-m-d');
              $warning = '';
              if($row['status'] === 'Pending') {
                  $warning = 'pending';
              } elseif($row['status'] != 'Closed' && 
                 !empty($row['target_tanggal']) && 
                 $row['target_tanggal'] < $today){
                  $warning = 'late';
              }
            ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= htmlspecialchars($row['nama']) ?></td>
              <td><?php $u=strtolower($row['urgency']);$uc=$u==='high'?'#ef4444':($u==='medium'?'#f59e0b':'#22c55e'); ?>
                <span class="urgency-badge" style="color:<?= $uc ?>;"><?= $row['urgency'] ?></span>
              </td>
              <td><?= htmlspecialchars($row['todo']) ?></td>
              <td><?= htmlspecialchars($row['departemen']) ?></td>
              <td><?= htmlspecialchars($row['DIVISI']??$row['divisi']??'') ?></td>
              <td><?=htmlspecialchars($row['keterangan']) ?></td>
              <td>
                <form method="POST" class="status-form">
                  <input type="hidden" name="task_id" value="<?= $row['id'] ?>">
                  <select name="status" class="status-select">
                    <option value="Open"    <?= $row['status']==='Open'    ?'selected':'' ?>>Open</option>
                    <option value="Pending" <?= $row['status']==='Pending' ?'selected':'' ?>>Pending</option>
                    <option value="Process" <?= $row['status']==='Process' ?'selected':'' ?>>Process</option>
                    <option value="Closed"  <?= $row['status']==='Closed'  ?'selected':'' ?>>Closed</option>
                  </select>
                  <button type="submit" name="update_status" class="btn-status">OK</button>
                </form>
              </td>
              <td><?php
                $dt=new DateTime($row['created_at']);
                $hari=['Sunday'=>'Min','Monday'=>'Sen','Tuesday'=>'Sel','Wednesday'=>'Rab','Thursday'=>'Kam','Friday'=>'Jum','Saturday'=>'Sab'];
                $bulan=['01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'Mei','06'=>'Jun','07'=>'Jul','08'=>'Agu','09'=>'Sep','10'=>'Okt','11'=>'Nov','12'=>'Des'];
                echo $hari[$dt->format('l')].', '.$dt->format('d').' '.$bulan[$dt->format('m')].' '.$dt->format('Y').' '.$dt->format('H:i');
              ?></td>
              <td><?= $row['target_tanggal'] ?></td>
              <td>
                <?php if($warning === 'late'): ?>
                  <span style="color:red;font-weight:bold;">⚠️ Late</span>
                <?php elseif($warning === 'pending'): ?>
                  <span style="color:orange;font-weight:bold;">⏳ Pending</span>
                <?php else: ?>
                  <span style="color:lime;">On Time</span>
                <?php endif; ?>
              </td>
              <td>
                <button class="btn-edit" onclick="openEditModal(<?= $row['id'] ?>)">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit
                </button>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ===== MODAL EDIT TASK ===== -->
  <div class="modal-overlay" id="editModal" onclick="closeModalOutside(event)">
    <div class="modal-box" id="modalBox">
      <button class="modal-close" onclick="closeEditModal()">✕</button>
      <div id="modalContent">
        <div class="modal-loading"><div class="spinner"></div> Loading...</div>
      </div>
    </div>
  </div>

  <!-- Data users untuk JS -->
  <script>
    const USERS = <?= json_encode($users_list) ?>;
    const TODAY = '<?= date('Y-m-d') ?>';

    // ===== MODAL OPEN/CLOSE =====
    function openEditModal(id) {
      document.getElementById('editModal').classList.add('active');
      document.body.style.overflow = 'hidden';
      loadModalContent(id);
    }
    function closeEditModal() {
      document.getElementById('editModal').classList.remove('active');
      document.body.style.overflow = '';
      document.getElementById('modalContent').innerHTML = '<div class="modal-loading"><div class="spinner"></div> Loading...</div>';
    }
    function closeModalOutside(e) {
      if(e.target === document.getElementById('editModal')) closeEditModal();
    }
    document.addEventListener('keydown', e => { if(e.key === 'Escape') closeEditModal(); });

    // ===== LOAD DATA TASK =====
    async function loadModalContent(id) {
      const res  = await fetch(`edit_task.php?id=${id}&json=1`);
      const data = await res.json();
      renderModal(data);
    }

    // ===== RENDER MODAL =====
    function renderModal(d) {
      const isPending = d.status === 'Pending';

      // Build user options
      let userOpts = '<option value="">-- Pilih User --</option>';
      USERS.forEach(u => { userOpts += `<option value="${u.id}">${u.username}</option>`; });

      // Build target history rows
      let histRows = '';
      if(d.targets && d.targets.length > 0) {
        d.targets.forEach(t => {
          histRows += `<tr>
            <td style="color:#f59e0b;">${t.target_tanggal}</td>
            <td>${t.username || '-'}</td>
            <td style="color:#aaa;">${t.catatan || '-'}</td>
            <td style="color:#55556a;">${t.created_at}</td>
          </tr>`;
        });
      }

      // Pending section
      const pendingHTML = isPending ? `
        <div class="pending-section">
          <div class="pending-section-title">⏳ Tambah Target Baru (Status: Pending)</div>
          <div class="mform-row">
            <div class="mform-group">
              <label>Target Tanggal Baru</label>
              <input type="date" id="m_target_baru" min="${TODAY}">
            </div>
            <div class="mform-group">
              <label>Assign ke User</label>
              <select id="m_assigned_to">${userOpts}</select>
            </div>
          </div>
          <div class="mform-group">
            <label>Catatan (opsional)</label>
            <textarea id="m_catatan" placeholder="Tulis catatan untuk user..."></textarea>
          </div>
          <button class="btn-add-target" onclick="submitTambahTarget(${d.id})">+ Tambah Target</button>

          ${d.targets && d.targets.length > 0 ? `
          <div style="margin-top:14px;">
            <div style="font-size:0.75rem;color:#55556a;font-weight:600;margin-bottom:6px;">RIWAYAT TARGET TAMBAHAN</div>
            <table class="target-history-table">
              <thead><tr>
                <th>Target</th><th>Assigned To</th><th>Catatan</th><th>Dibuat</th>
              </tr></thead>
              <tbody>${histRows}</tbody>
            </table>
          </div>` : ''}
        </div>` : '';

      document.getElementById('modalContent').innerHTML = `
        <div class="modal-title">✏️ Edit Task #${d.id}</div>

        <div class="modal-section">
          <div class="modal-section-title">Info Task</div>
          <div class="mform-row">
            <div class="mform-group">
              <label>Nama</label>
              <input type="text" id="m_nama" value="${escHtml(d.nama)}">
            </div>
            <div class="mform-group">
              <label>Urgency</label>
              <select id="m_urgency">
                <option value="Low"    ${d.urgency==='Low'   ?'selected':''}>Low</option>
                <option value="Medium" ${d.urgency==='Medium'?'selected':''}>Medium</option>
                <option value="High"   ${d.urgency==='High'  ?'selected':''}>High</option>
              </select>
            </div>
          </div>
          <div class="mform-group">
            <label>Todo / Task</label>
            <textarea id="m_todo">${escHtml(d.todo)}</textarea>
          </div>
          <div class="mform-row">
            <div class="mform-group">
              <label>Departemen</label>
              <input type="text" id="m_departemen" value="${escHtml(d.departemen)}">
            </div>
            <div class="mform-group">
              <label>Divisi</label>
              <input type="text" id="m_divisi" value="${escHtml(d.divisi)}">
            </div>
          </div>
          <div class="mform-group">
            <label>Status</label>
            <select id="m_status">
              <option value="Open"    ${d.status==='Open'   ?'selected':''}>Open</option>
              <option value="Pending" ${d.status==='Pending'?'selected':''}>Pending</option>
              <option value="Process" ${d.status==='Process'?'selected':''}>Process</option>
              <option value="Closed"  ${d.status==='Closed' ?'selected':''}>Closed</option>
            </select>
          </div>
        </div>

        ${pendingHTML}

        <div class="modal-footer">
          <button class="btn-modal-danger" onclick="hapusTask(${d.id})">🗑 Hapus</button>
          <button class="btn-modal-save"   onclick="submitUpdate(${d.id})">💾 Simpan</button>
        </div>
      `;
    }

    // ===== SUBMIT UPDATE =====
    async function submitUpdate(id) {
      const body = new FormData();
      body.append('update', '1');
      body.append('nama',       document.getElementById('m_nama').value);
      body.append('urgency',    document.getElementById('m_urgency').value);
      body.append('todo',       document.getElementById('m_todo').value);
      body.append('departemen', document.getElementById('m_departemen').value);
      body.append('divisi',     document.getElementById('m_divisi').value);
      body.append('status',     document.getElementById('m_status').value);

      const res  = await fetch(`edit_task.php?id=${id}&json=1`, { method:'POST', body });
      const data = await res.json();
      if(data.success) {
        showToastModal('Task berhasil diupdate!', false);
        closeEditModal();
        setTimeout(() => location.reload(), 900);
      } else {
        showToastModal('Gagal update task.', true);
      }
    }

    // ===== SUBMIT TAMBAH TARGET =====
    async function submitTambahTarget(id) {
      const target_baru  = document.getElementById('m_target_baru').value;
      const assigned_to  = document.getElementById('m_assigned_to').value;
      const catatan      = document.getElementById('m_catatan').value;
      if(!target_baru || !assigned_to) { showToastModal('Target tanggal & user wajib diisi!', true); return; }

      const body = new FormData();
      body.append('tambah_target', '1');
      body.append('target_baru',   target_baru);
      body.append('assigned_to',   assigned_to);
      body.append('catatan',       catatan);

      const res  = await fetch(`edit_task.php?id=${id}&json=1`, { method:'POST', body });
      const data = await res.json();
      if(data.success) {
        showToastModal('Target berhasil ditambahkan!', false);
        loadModalContent(id); // refresh modal
      } else {
        showToastModal('Gagal tambah target.', true);
      }
    }

    // ===== HAPUS TASK =====
    function hapusTask(id) {
      if(!confirm('Yakin hapus task ini? Ga bisa balik lagi lho.')) return;
      window.location = `edit_task.php?id=${id}&hapus=${id}`;
    }

    // ===== TOAST MODAL =====
    function showToastModal(msg, isError) {
      const t = document.getElementById('toastModal');
      t.textContent = msg;
      t.className = 'toast' + (isError ? ' red' : '');
      t.style.display = 'block';
      setTimeout(() => { t.style.transition='opacity 0.4s'; t.style.opacity='0'; setTimeout(()=>{ t.style.display='none'; t.style.opacity='1'; },400); }, 3000);
    }

    // ===== UTIL =====
    function escHtml(str) {
      if(!str) return '';
      return String(str).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    // Auto-hide toast
    const toast = document.getElementById('toast');
    if(toast) setTimeout(()=>{ toast.style.transition='opacity 0.4s'; toast.style.opacity='0'; setTimeout(()=>toast.remove(),400); }, 3000);
  </script>
</body>
</html>